"""CPU-only mathematical reference for the DPO TRO handoff.

No model or dataset downloads. This is not the production trainer.
Run `python3 reference_math.py` to check identities and numerical edge cases.
"""

import json
import math
import random


def sigmoid(z):
    if z >= 0:
        return 1.0 / (1.0 + math.exp(-z))
    exp_z = math.exp(z)
    return exp_z / (1.0 + exp_z)


def softplus(z):
    return max(z, 0.0) + math.log1p(math.exp(-abs(z)))


def soft_loss(z, probability):
    assert 0.0 <= probability <= 1.0
    # This form avoids subtracting two large nearly equal numbers.
    return probability * softplus(-z) + (1.0 - probability) * softplus(z)


def bernoulli_kl(empirical, candidate):
    """KL(Ber(empirical) || Ber(candidate)); natural logarithms."""
    assert 0.0 <= empirical <= 1.0
    assert 0.0 <= candidate <= 1.0
    if empirical == candidate:
        return 0.0
    if candidate == 0.0 or candidate == 1.0:
        return math.inf
    if empirical == 0.0:
        return -math.log1p(-candidate)
    if empirical == 1.0:
        return -math.log(candidate)
    return (
        empirical * (math.log(empirical) - math.log(candidate))
        + (1.0 - empirical)
        * (math.log1p(-empirical) - math.log1p(-candidate))
    )


def kl_interval(empirical, radius, steps=100):
    """Endpoints of KL(Ber(empirical) || Ber(p)) <= radius."""
    assert 0.0 <= empirical <= 1.0
    assert math.isfinite(radius) and radius >= 0.0
    if radius == 0.0:
        return empirical, empirical
    if empirical == 0.0:
        return 0.0, -math.expm1(-radius)
    if empirical == 1.0:
        return math.exp(-radius), 1.0
    outside, inside = 0.0, empirical
    for _ in range(steps):
        mid = (outside + inside) / 2.0
        if bernoulli_kl(empirical, mid) > radius:
            outside = mid
        else:
            inside = mid
    lower = inside
    inside, outside = empirical, 1.0
    for _ in range(steps):
        mid = (inside + outside) / 2.0
        if bernoulli_kl(empirical, mid) > radius:
            outside = mid
        else:
            inside = mid
    return lower, inside


def n_radius(n_votes, delta=0.05, eta=1.0):
    assert n_votes > 0 and 0.0 < delta < 1.0 and eta >= 0.0
    return eta * math.log((n_votes + 1.0) / delta) / n_votes


def lambda_from_n(n_votes, n0):
    assert n_votes > 0 and n0 >= 0.0
    return 1.0 if math.isinf(n0) else n0 / (n_votes + n0)


def tro_loss_and_gradient(z, empirical, lower, upper, lam):
    """Returns loss and its derivative w.r.t. margin z, not model weights.

    At z=0 chooses the empirical-center subgradient by convention.
    """
    assert 0.0 <= lower <= empirical <= upper <= 1.0
    assert 0.0 <= lam <= 1.0
    worst = lower if z > 0 else upper if z < 0 else empirical
    target = (1.0 - lam) * empirical + lam * worst
    return soft_loss(z, target), sigmoid(z) - target


def independent_margin_optimal_probability(lower, upper):
    """Optimal q for min_z max_{p in [lower,upper]} ell(z,p)."""
    return min(upper, max(lower, 0.5))


def _close(left, right, atol=1e-10):
    assert math.isclose(left, right, rel_tol=1e-9, abs_tol=atol), (left, right)


def run_self_checks():
    rng = random.Random(260126)
    identity_error = 0.0
    gradient_error = 0.0
    kl_residual = 0.0
    for _ in range(500):
        empirical = rng.uniform(0.02, 0.98)
        radius = rng.uniform(0.0001, 0.15)
        lower, upper = kl_interval(empirical, radius)
        assert lower <= empirical <= upper
        for endpoint in (lower, upper):
            error = abs(bernoulli_kl(empirical, endpoint) - radius)
            kl_residual = max(kl_residual, error)
            assert error < 1e-8

        lam = rng.random()
        z = rng.choice([-1, 1]) * rng.uniform(0.01, 8.0)
        value, grad = tro_loss_and_gradient(z, empirical, lower, upper, lam)
        mix = (1 - lam) * soft_loss(z, empirical) + lam * max(
            soft_loss(z, lower), soft_loss(z, upper)
        )
        expanded = soft_loss(z, empirical) + lam * (
            (empirical - lower) * max(z, 0.0)
            + (upper - empirical) * max(-z, 0.0)
        )
        shrunk_lower = (1 - lam) * empirical + lam * lower
        shrunk_upper = (1 - lam) * empirical + lam * upper
        contracted = max(soft_loss(z, shrunk_lower), soft_loss(z, shrunk_upper))
        for alternate in (mix, expanded, contracted):
            identity_error = max(identity_error, abs(value - alternate))
            _close(value, alternate)

        # Independent dense inner maximization, including endpoints.
        grid_max = max(soft_loss(z, lower + (upper - lower) * j / 100)
                       for j in range(101))
        _close(grid_max, max(soft_loss(z, lower), soft_loss(z, upper)))

        step = 1e-5
        plus = tro_loss_and_gradient(z + step, empirical, lower, upper, lam)[0]
        minus = tro_loss_and_gradient(z - step, empirical, lower, upper, lam)[0]
        numeric_grad = (plus - minus) / (2 * step)
        gradient_error = max(gradient_error, abs(grad - numeric_grad))
        _close(grad, numeric_grad, atol=2e-9)

        swapped_value, swapped_grad = tro_loss_and_gradient(
            -z, 1 - empirical, 1 - upper, 1 - lower, lam
        )
        _close(value, swapped_value)
        _close(grad, -swapped_grad)
        _close(tro_loss_and_gradient(z, empirical, lower, upper, 0)[0],
               soft_loss(z, empirical))
        _close(tro_loss_and_gradient(z, empirical, lower, upper, 1)[0], grid_max)

    for empirical in (0.0, 0.1, 0.5, 0.9, 1.0):
        for radius in (0.0, 1e-6, 0.01, 0.5, 2.0):
            lower, upper = kl_interval(empirical, radius)
            assert 0 <= lower <= empirical <= upper <= 1
            for z in (-1000.0, -2.0, 0.0, 2.0, 1000.0):
                for lam in (0.0, 0.5, 1.0):
                    value, grad = tro_loss_and_gradient(z, empirical, lower, upper, lam)
                    assert math.isfinite(value) and math.isfinite(grad)
                    if z == 0:
                        _close(value, math.log(2))
                        _close(grad, 0.5 - empirical)
                    if radius == 0:
                        _close(value, soft_loss(z, empirical))

    for n_votes in (5, 10, 20, 100):
        for k in range(n_votes + 1):
            empirical = k / n_votes
            for z in (-3.0, 0.0, 3.0):
                explicit = (k * soft_loss(z, 1.0)
                            + (n_votes - k) * soft_loss(z, 0.0)) / n_votes
                _close(explicit, soft_loss(z, empirical))
                explicit_grad = (k * (sigmoid(z) - 1)
                                 + (n_votes - k) * sigmoid(z)) / n_votes
                _close(explicit_grad, sigmoid(z) - empirical)

    # Exact enumeration of the stated per-pair coverage for selected cases.
    minimum_coverage = 1.0
    for n_votes in (5, 10, 20, 100):
        for p_star in (0.01, 0.1, 0.3, 0.5, 0.7, 0.9, 0.99):
            radius = n_radius(n_votes)
            coverage = 0.0
            for k in range(n_votes + 1):
                if bernoulli_kl(k / n_votes, p_star) <= radius + 1e-12:
                    coverage += (math.comb(n_votes, k) * p_star**k
                                 * (1-p_star)**(n_votes-k))
            minimum_coverage = min(minimum_coverage, coverage)
            assert coverage >= 0.95 - 1e-12

    # Two independent-margin chi-square example from the protocol.
    center, radius = 0.7, 1 / 21
    half_width = math.sqrt(radius * center * (1 - center))
    lower, upper = center - half_width, center + half_width
    qs = []
    for n_votes in (10, 100):
        lam = lambda_from_n(n_votes, 10)
        a = (1-lam) * center + lam * lower
        b = (1-lam) * center + lam * upper
        qs.append(independent_margin_optimal_probability(a, b))
    _close(qs[0], 13 / 20)
    _close(qs[1], 38 / 55)
    assert abs(qs[0] - qs[1]) > 0.04

    return {
        "status": "passed",
        "random_identity_cases": 500,
        "max_loss_identity_error": identity_error,
        "max_finite_difference_margin_gradient_error": gradient_error,
        "max_regular_case_kl_endpoint_residual": kl_residual,
        "minimum_coverage_on_enumerated_grid": minimum_coverage,
        "chi_square_tro_optimal_q": qs,
        "scope": "scalar mathematics only; no PyTorch autograd, GPU, RM or LLM training tested"
    }


if __name__ == "__main__":
    print(json.dumps(run_self_checks(), ensure_ascii=False, indent=2))
