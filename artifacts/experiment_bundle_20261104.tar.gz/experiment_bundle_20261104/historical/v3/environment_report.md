# Runtime and experiment report

Date: 2026-10-26 UTC. Repository: `/mnt/hezhisheng/distributionally_robust_dpo-2`, source commit at scan `d6dc68bbaaa51c60b7d1b6ccd991fc6fbc72de4e` (the repository already contained unrelated uncommitted work).

## Resolved runtime

- Python environment: `.venv`
- PyTorch: `2.5.1+cu124`
- Transformers: `4.48.3`
- Datasets: `5.0.1`
- DeepSpeed: `0.16.4`
- vLLM: `0.7.2`
- OpenRLHF: `0.6.1.post1`
- GPUs: 8 x H100 80GB; other jobs occupied several devices, so runs used available physical devices sequentially or in parallel.
- Policy base/reference: local `models/Llama1b` (Llama-3.2-1B-Instruct compatible checkpoint); reference is frozen and initialized from the same checkpoint.
- Frozen teacher: local `models/ArmoRM`, score field `score`, BF16, eval/inference mode.
- UltraFeedback snapshot: HuggingFace dataset commit `3949bf5f8c17c394422ccfab0c31ea9c20bdeb85`.

## Data and simulation

- Source rows: 61,135 train and 2,000 official test rows.
- Deduplicated fixed pairs: 61,124 train and 2,000 test; no train/test prompt overlap after prompt-level filtering.
- Pilot split: 2,000 train, 200 dev, 500 test; one randomized response order per pair (response-order seed 1730).
- Frozen ArmoRM train-only temperature: `T_pref = 0.02685546875`.
- Pilot observations: n in {5, 10, 20, 100}, balanced allocation, vote seed 101, allocation seed 1731, common KL radius 0.05, n-radius eta=1/delta=0.05, lambda rule n0=10.
- Ordinary method records contain only observed vote metadata; oracle records are separate and carry `p_star`.

## Training

All comparable pilot checkpoints below use the same 2,000 training pairs, two epochs, BF16, learning rate 5e-7, beta 0.01, effective batch argument 16, gradient checkpointing, and policy sequence cap 512 (the cap was reduced uniformly after the initial smoke run because of concurrent GPU occupancy). Each has a HF-format `checkpoints/final_hf` export.

- `hard_dpo`
- `soft_dpo`
- `label_dro_common`
- `tro_common`
- `oracle_soft_dpo`
- `label_dro_n`
- `tro_n`

## Generation evaluation

For all seven pilot checkpoints (hard-DPO, soft-DPO, label-DRO-common, TRO-common, oracle-soft-DPO, label-DRO-n, and TRO-n), the protocol used the same 500 test prompts, 10 stochastic samples per prompt, seed 401, temperature 0.7, top-p 0.9, max 256 new tokens, then scored every response with the frozen ArmoRM. Aggregation is mean within prompt, then mean over prompts. `pilot_metrics.json` contains paired prompt bootstrap intervals (2,000 replicates, seed 601).

Formal-scale (non-pilot) training was not started.

## Follow-up scenario: N_i in {1, 3, 5, 7, 9}

The requested follow-up was run with the same fixed pairs, ArmoRM oracle, base/reference policy, 512-token policy cap, and two epochs. Allocation is exactly 400/400/400/400/400 on the 2,000-pair train split, 40/40/40/40/40 on dev, and 100/100/100/100/100 on test. Outputs are under `data/observations/pilot/seed101_n13579`, `data/methods/pilot/seed101_n13579`, `outputs/pilot_n13579_*`, and `eval/pilot_n13579_*`.

All seven methods have final checkpoints and completed 500 x 10 generation plus ArmoRM scoring. The aggregate is in `eval/pilot_n13579_metrics.json`. The oracle-policy mean reward is 0.06908444; hard-DPO 0.06865548, soft-DPO 0.06867858, label-DRO-common 0.06860975, TRO-common 0.06913625, label-DRO-n 0.06803791, and TRO-n 0.06768603. These are one pilot seed and should not be treated as a final statistical conclusion.

## Detailed result reports

- `report_n13579.md`: detailed report for `N_i in {1,3,5,7,9}`.
- `report_n051020100.md`: detailed report for the previous `N_i in {5,10,20,100}` run.
- `report_comparison.md`: side-by-side comparison of the two scenarios.
