# Pilot 结果报告：$N_i\in\{1,3,5,7,9\}$

生成时间：2026-10-27  
实验目录：`/mnt/hezhisheng/su/experiment_handoff_v3`  
场景名：`pilot_n13579`  
协议版本：`2026-10-26-v3`

## 1. 结论摘要

本轮按照每道题标注数 `N_i∈{1,3,5,7,9}`、五档等量分配完成了 7 个方法的训练、生成和 ArmoRM 评分。每个方法均训练 2 个 epoch，并在 500 个测试 prompt 上各生成 10 个回答，共 5,000 条回答。

- `TRO-common` 的平均生成奖励最接近本轮 `oracle-soft-DPO`：差值为 `+0.00005181`（method − oracle）。
- `soft-DPO`、`hard-DPO` 和 `label-DRO-common` 也处于接近 oracle 的范围内，差值绝对值分别为 `0.00040586`、`0.00042896` 和 `0.00047469`。
- 两个按标注数调半径的方法在本轮表现较差：`label-DRO-n` 的差值为 `-0.00104653`，`TRO-n` 为 `-0.00139842`；对应的 paired prompt bootstrap 95% 区间均低于 0。
- 这些结果是单个 pilot seed、2 epoch、统一 512-token 策略长度下的结果，适合用于方法筛选和机制诊断，不能作为多重复正式结论。

这里的 oracle 是使用冻结 ArmoRM 构造的 `p*` 训练得到的参照模型，不是理论上界，也不代表人工偏好真值。

## 2. 实验设置

### 数据与标注场景

| 项目 | 设置 |
|---|---|
| 数据集 | `HuggingFaceH4/ultrafeedback_binarized` |
| 数据 revision | `3949bf5f8c17c394422ccfab0c31ea9c20bdeb85` |
| pilot 划分 | train 2,000 对；dev 200 prompt；test 500 prompt |
| 训练标注数 | `N_i∈{1,3,5,7,9}`，每档 400 对，合计 2,000 |
| dev 标注数 | 每档 40 对，合计 200 |
| test 标注数 | 每档 100 对，合计 500 |
| 分配 seed | 1731 |
| 模拟投票 seed | 101 |
| 回答顺序 seed | 1730 |
| split seed | 1729 |
| 训练 pair 权重 | 题目均匀加权 `1/N`，不按票数加权 |

五档的观测由同一批 pair、同一套冻结教师和同一投票规则产生。普通训练数据不读取 `p*` 或教师原始分数；`oracle-soft-DPO` 单独使用教师构造的 `p*`。

### 教师、oracle 与不确定性规则

| 项目 | 实际设置 |
|---|---|
| 冻结 reward model | `RLHFlow/ArmoRM-Llama3-8B-v0.1` |
| 本地路径 | `models/ArmoRM` |
| 评分字段 | 官方 `output.score`，字段名 `score` |
| `T_pref` | `0.02685546875`，仅由最终 train 清单的非零绝对分差中位数确定 |
| oracle 概率 | `p*=sigmoid((score_1-score_2)/T_pref)` |
| common KL 半径 | `rho=0.05` |
| n-adaptive 半径 | `rho_i=eta*log((N_i+1)/delta)/N_i` |
| `eta`, `delta` | `eta=1`, `delta=0.05` |
| TRO 折中 | `lambda_i=n0/(N_i+n0)`，`n0=10` |

`label-DRO-common` 和 `TRO-common` 使用统一半径；`label-DRO-n` 和 `TRO-n` 使用按 `N_i` 调整的半径。`TRO` 在题内名义 soft loss 与最坏端点 loss 之间按 `lambda_i` 折中。

### 策略训练与生成

| 项目 | 实际设置 |
|---|---|
| policy base/reference | 本地 `models/Llama1b`；reference 冻结且等于初始 checkpoint |
| 训练方式 | 全参数训练，所有方法从同一初始模型开始 |
| epoch | 2 |
| learning rate | `5e-7` |
| DPO `beta` | `0.01` |
| 策略最大序列长度 | `512`；所有方法统一，受 GPU 并发资源限制 |
| dtype | BF16；loss 计算保持 float32 |
| gradient checkpointing | 开启 |
| DeepSpeed | ZeRO stage 2 |
| microbatch | 1 |
| 训练 batch 参数 | 16（实际运行值；协议候选默认的 128 未使用） |
| 优化器相关 | Adam，betas `(0.9,0.95)`，weight decay `0`，warmup ratio `0.1`，clip norm `1.0` |
| generation seed | 401 |
| 每个 prompt 样本数 | `K=10` |
| generation temperature / top-p | `0.7` / `0.9` |
| max new tokens | `256` |
| 评测聚合 | 先题内 10 个回答取均值，再对 500 个 prompt 取均值 |
| bootstrap | 2,000 个 paired-prompt replicates，seed 601，95% CI |

运行环境：8×H100 80GB；PyTorch `2.5.1+cu124`、Transformers `4.48.3`、Datasets `5.0.1`、DeepSpeed `0.16.4`、vLLM `0.7.2`、OpenRLHF `0.6.1.post1`。

评测时所有生成回答均由同一个冻结 ArmoRM 重新评分，不使用 best-of-K。7 个方法的 generation 和 scoring 文件均为 5,000 行。

## 3. 方法说明

| 方法 | 训练目标 |
|---|---|
| `hard-DPO` | 多数票方向的 hard label |
| `soft-DPO` | 使用经验偏好 `p_hat` |
| `label-DRO-common` | 在 `KL(p_hat || p)≤0.05` 的题内球上取最坏损失 |
| `TRO-common` | common-DRO 最坏损失与 soft loss 按 `lambda_i` 折中 |
| `oracle-soft-DPO` | 使用教师构造的 `p*`，作为信息充分参照 |
| `label-DRO-n` | 使用 `rho_i=log((N_i+1)/0.05)/N_i` 的题目自适应半径 |
| `TRO-n` | n-adaptive DRO 球上的 TRO 折中 |

## 4. 测试结果

`method − oracle` 为方法平均 reward 减去同轮 oracle 平均 reward；越接近 0 越接近 oracle。`oracle − method` 可直接理解为正向落后量。CI 是 `method − oracle` 的 paired prompt bootstrap 95% 区间。

| 方法 | mean reward | method − oracle | oracle − method | paired bootstrap CI 95% | 备注 |
|---|---:|---:|---:|---:|---|
| `TRO-common` | 0.06913625 | +0.00005181 | -0.00005181 | [-0.00065645, 0.00077448] | 绝对差最小 |
| `oracle-soft-DPO` | 0.06908444 | 0 | 0 | [0, 0] | 参照 |
| `soft-DPO` | 0.06867858 | -0.00040586 | +0.00040586 | [-0.00099936, 0.00018481] | 接近 oracle |
| `hard-DPO` | 0.06865548 | -0.00042896 | +0.00042896 | [-0.00104612, 0.00018541] | 接近 oracle |
| `label-DRO-common` | 0.06860975 | -0.00047469 | +0.00047469 | [-0.00113975, 0.00022150] | 接近 oracle |
| `label-DRO-n` | 0.06803791 | -0.00104653 | +0.00104653 | [-0.00193544, -0.00022022] | 低于 oracle，CI 不跨 0 |
| `TRO-n` | 0.06768603 | -0.00139842 | +0.00139842 | [-0.00224432, -0.00057188] | 本轮最低，CI 不跨 0 |

### 结果解读

在本轮 `N_i={1,3,5,7,9}` 下，统一半径的 `TRO-common` 最接近 oracle。按标注量缩放半径后，低票数题会得到更大的不确定性半径；在这次训练规模和 seed 下，这种更强的保守化没有带来收益，`label-DRO-n` 和 `TRO-n` 反而明显落后。该现象应作为机制诊断结果，而不是直接推广到正式规模。

`hard-DPO`、`soft-DPO` 和 `label-DRO-common` 的 bootstrap 区间均跨过 0，说明在当前 500 prompt 测试和单个生成 seed 下，不能把它们与 oracle 的差异解释成稳定的正负差异。`TRO-common` 的点估计略高于 oracle，但区间同样跨 0。

## 5. 可复现文件

- 指标：[pilot_n13579_metrics.json](/mnt/hezhisheng/su/experiment_handoff_v3/eval/pilot_n13579_metrics.json)
- 运行 manifest：[resolved_runtime_manifest_n13579.json](/mnt/hezhisheng/su/experiment_handoff_v3/resolved_runtime_manifest_n13579.json)
- 新场景 observations：`/mnt/hezhisheng/su/experiment_handoff_v3/data/observations/pilot/seed101_n13579/`
- 新场景 method records：`/mnt/hezhisheng/su/experiment_handoff_v3/data/methods/pilot/seed101_n13579/`
- checkpoint：`/mnt/hezhisheng/su/experiment_handoff_v3/outputs/pilot_n13579_<method>/checkpoints/final_hf/`
- 生成与评分：`/mnt/hezhisheng/su/experiment_handoff_v3/eval/pilot_n13579_<method>/`
- 共享实验协议：[EXPERIMENT_PROTOCOL.md](/mnt/hezhisheng/su/experiment_handoff_v3/EXPERIMENT_PROTOCOL.md)

## 6. 限制

1. 这是 pilot：单个投票 seed、单个训练 seed、单个生成 seed，尚未覆盖协议中计划的多重复实验。
2. 训练序列上限统一设为 512，而协议候选值是 2,048；这是资源约束下的公平缩短，不应与不同长度配置直接比较。
3. 实际训练 batch 参数为 16，不是协议默认候选的 effective batch 128；两轮方法之间保持一致，但与正式规模配置不等价。
4. 当前汇总的是生成 reward，尚未在本报告中展开 pair-level oracle risk、概率 MSE、长度和截断率等辅助指标。
5. ArmoRM 同时用于 oracle 构造和生成评测，结果反映的是该冻结教师的一致性，不是跨 reward model 的稳健性。
