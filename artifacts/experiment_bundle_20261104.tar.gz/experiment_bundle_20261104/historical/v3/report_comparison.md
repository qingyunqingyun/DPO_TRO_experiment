# 两轮 pilot 对比报告

对比场景：

- 上一轮：`N_i∈{5,10,20,100}`，场景 `pilot`
- 本轮：`N_i∈{1,3,5,7,9}`，场景 `pilot_n13579`

两轮使用同一套 2,000/200/500 pilot 划分、同一 base/reference policy、同一冻结 ArmoRM、同一 `T_pref=0.02685546875`、相同训练和生成设置。变化项主要是每题的标注数分布及由此产生的 `p_hat`、KL 半径和 TRO lambda。

## 1. 共同设置与变化

| 项目 | 两轮共同设置 | 上一轮 | 本轮 |
|---|---|---|---|
| 标注量 | 等量分配 | `{5,10,20,100}` | `{1,3,5,7,9}` |
| 每档 train/dev/test | — | train/dev 为 500/50；test 仅做生成评测 | 400/40/100 |
| reward model | ArmoRM `output.score` | 相同 | 相同 |
| `T_pref` | 训练集非零绝对分差中位数 | 0.02685546875 | 0.02685546875 |
| common radius | `rho=0.05` | 相同 | 相同 |
| n-radius | `log((N_i+1)/0.05)/N_i` | `eta=1` | `eta=1` |
| TRO | `lambda=10/(N_i+10)` | 相同规则 | 相同规则 |
| 训练 | 2 epoch、LR 5e-7、beta 0.01、BF16、max_len 512 | 相同 | 相同 |
| 评测 | 500 prompt × 10 samples、seed 401、ArmoRM | 相同 | 相同 |

## 2. 平均 reward 与跨轮差值

`本轮−上一轮` 是平均生成 reward 的变化；`gap` 是 method − oracle，越接近 0 越接近各自场景的 oracle。

| 方法 | 上一轮 reward | 本轮 reward | 本轮−上一轮 | 上一轮 gap | 本轮 gap |
|---|---:|---:|---:|---:|---:|
| `hard-DPO` | 0.06798629 | 0.06865548 | +0.00066919 | -0.00051260 | -0.00042896 |
| `soft-DPO` | 0.06813556 | 0.06867858 | +0.00054302 | -0.00036333 | -0.00040586 |
| `label-DRO-common` | 0.06934108 | 0.06860975 | -0.00073133 | +0.00084219 | -0.00047469 |
| `TRO-common` | 0.06913062 | 0.06913625 | +0.00000563 | +0.00063173 | +0.00005181 |
| `label-DRO-n` | 0.06807419 | 0.06803791 | -0.00003628 | -0.00042470 | -0.00104653 |
| `TRO-n` | 0.06876217 | 0.06768603 | -0.00107615 | +0.00026328 | -0.00139842 |
| `oracle-soft-DPO` | 0.06849889 | 0.06908444 | +0.00058555 | 0 | 0 |

## 3. 主要观察

1. oracle 的 mean reward 从 `0.06849889` 变为 `0.06908444`，两轮的绝对 reward 水平不能直接当成同一测试环境中的纵向提升；应优先看每轮相对本轮 oracle 的 gap。
2. `TRO-common` 是最稳定的候选：上一轮 gap 为 `+0.00063173`，本轮变为 `+0.00005181`，本轮点估计几乎贴近 oracle。
3. `TRO-n` 从上一轮绝对差最小（`0.00026328`）变成本轮绝对差最大之一（`0.00139842`）。这说明按标注数缩放半径的收益对标注量分布很敏感，不能仅凭上一轮结果选它作为主方法。
4. `label-DRO-common` 在上一轮高于 oracle，在本轮低于 oracle；其 gap 变化为 `-0.00131688`。这更像是场景/生成抽样变化下的敏感性信号，而非稳定方向。
5. `label-DRO-n` 两轮均低于 oracle，本轮差距进一步扩大；本轮 paired bootstrap CI 不跨 0，但仍只有一个 seed。
6. `hard-DPO` 和 `soft-DPO` 两轮都与各自 oracle 保持较小绝对差，且对应的单轮 CI 均跨 0，是当前最保守的基线。

## 4. 当前建议

若下一步需要在正式多重复实验中先固定一个主候选，建议优先保留 `TRO-common`，同时保留 `soft-DPO`、`hard-DPO` 和 `oracle-soft-DPO` 作为共同基线/参照；将 `label-DRO-n` 与 `TRO-n` 作为按标注数半径的诊断对照，不因单轮结果直接淘汰或宣称有效。正式比较应至少重新覆盖多组投票、训练和生成 seed，并使用独立测试集。

## 5. 文件索引

- 本轮详细报告：[report_n13579.md](/mnt/hezhisheng/su/experiment_handoff_v3/report_n13579.md)
- 上一轮详细报告：[report_n051020100.md](/mnt/hezhisheng/su/experiment_handoff_v3/report_n051020100.md)
- 上一轮指标：[pilot_metrics.json](/mnt/hezhisheng/su/experiment_handoff_v3/eval/pilot_metrics.json)
- 本轮指标：[pilot_n13579_metrics.json](/mnt/hezhisheng/su/experiment_handoff_v3/eval/pilot_n13579_metrics.json)
- 上一轮 manifest：[resolved_runtime_manifest.json](/mnt/hezhisheng/su/experiment_handoff_v3/resolved_runtime_manifest.json)
- 本轮 manifest：[resolved_runtime_manifest_n13579.json](/mnt/hezhisheng/su/experiment_handoff_v3/resolved_runtime_manifest_n13579.json)
