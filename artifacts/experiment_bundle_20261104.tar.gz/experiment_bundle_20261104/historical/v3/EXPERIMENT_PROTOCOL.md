# UltraFeedback 上基于标注可靠性的 DPO TRO 实验流程

日期：2026-10-26。交付对象：合作者及负责扫描工程、实现数据和训练流程的 agent。

研究问题是：同一回答对的偏好概率由有限人数估计，且不同回答对的标注人数不同；逐题使用不同 TRO 折中强度，能否使训练策略的生成表现更接近直接使用真实偏好概率训练的 oracle soft DPO？本协议给出可执行的首轮设计。参数默认值属于待验证的设计，不代表方法已经有效。

## 1 研究范围和确定的选择

| 项目 | 本次选择 |
|---|---|
| 文本来源 | `HuggingFaceH4/ultrafeedback_binarized` 的固定问题与回答对 |
| 教师 RM | 优先核验 `Skywork/Skywork-Reward-V2-Llama-3.1-8B` 的适配性，随后冻结；ArmoRM 为补充教师 |
| 真实概率 | 由教师奖励分差经过 BT sigmoid 定义的 p* |
| 模拟观测 | 每对 n_i 个独立 Bernoulli 投票，得到 k_i 和 p_hat_i=k_i/n_i |
| 主名义标签 | empirical soft label；不默认改成后验均值 |
| 外层分布 | 每条回答对权重固定为 1/N；首轮每个 prompt 一对 |
| 鲁棒对象 | 每个固定回答对内部的二元偏好概率；不重新加权 prompt 或回答对 |
| 主要比较 | 多数票硬 DPO、soft DPO、统一半径标签 DRO、逐题 TRO、oracle soft DPO |
| 机制检查 | 增加按标注量调整半径的 DRO、同集合 TRO、固定 lambda、打乱可靠性等对照 |
| 主评测 | 测试问题上多次生成，由同一教师评分，报告平均奖励及 oracle 奖励差 |
| 辅助评测 | 固定测试回答对上的真实偏好交叉熵、概率误差和生成长度 |

这里的真实概率是人为规定的模拟环境真值。有限投票产生抽样误差；首轮不额外引入系统性错误标签。不要把此实验描述成已经抵御恶意标注或已经恢复真实人类偏好。

以下对象必须分别命名：

- `teacher_rm`：冻结评分函数 r_phi(x,y)。
- `oracle_probability`：教师定义的 p_i*。
- `oracle_policy`：使用 p_i* 训练的 soft DPO 策略。
- `reference_policy`：DPO 的冻结参考策略 pi_ref，不是 teacher RM。

## 2 接手 agent 先扫描什么

在合作者实际工作区先读取适用的 AGENTS.md、README、依赖锁定文件、训练入口、dataset/collator、loss、生成和 RM 评分代码。核对可用 GPU、显存、磁盘、模型缓存、CUDA、PyTorch、Transformers、OpenRLHF、DeepSpeed 与 vLLM 版本；保存实际版本，不凭历史对话猜测。

源端曾检查的旧工程位于 `drdpo_2epoch_tau001_rho0005_20260923 2/code/`，接手时按目录结构寻找，不硬编码发送者的绝对路径。已观察到的接口如下：

| 旧文件 | 当前用途 | 接手时的处理 |
|---|---|---|
| `src/train_alignment.py` | OpenRLHF RewardDataset、DPOTrainer，以及旧 KLDPO/WDPO 分支 | 可复用训练设施；新增携带票数和概率端点的数据接口及方法名 |
| `src/generate_preferences.py` | 各维度分数按 split 标准化、混合、取最高和最低回答生成硬偏好 | 新流程绕开该 pair 构造逻辑，直接读取 UltraFeedback 固定回答对 |
| `src/generate_completions.py` | vLLM 生成；ArmoRM 路径及多维输出写在代码中 | 生成部分可复用；RM 改成显式适配器与可配置路径 |
| `src/aggregate_prompt_metrics.py` | 按 prompt 汇总 | 核对是否先题内平均再题间平均，核对缺失样本和重复样本 |
| `train_alignment.sh` | 旧训练参数与环境覆盖 | 保存最终解析参数，不把文件夹名或旧截图当实际配置 |

已读取的旧脚本默认包含 effective batch=128、学习率 5e-7、beta=0.01、max_len=2048；环境变量或命令行可能覆盖。新实验应使用自己的冻结配置。不要复用旧实验训练后的 DPO/KLDPO/WDPO 权重作为不同方法的不同初始化。

扫描后输出 `environment_report.md`、代码复用与修改清单、实际运行配置。训练代码没有携带 n_i、k_i 的情况下，不能仅修改一个 loss 参数就声称实现了本实验。

## 3 数据划分与固定回答对

官方数据集链接：[UltraFeedback binarized](https://huggingface.co/datasets/HuggingFaceH4/ultrafeedback_binarized)。公开划分包括 `train_prefs` 和 `test_prefs`；本协议编写时数据卡分别显示 61,135 与 2,000 条。读取时记录实际数量和固定 revision。

从每条记录提取 x_i、y_i1、y_i2。原 `chosen/rejected` 用于取出文本，原分数与胜负不作为新 oracle。验证两侧 user 内容一致，避免把 prompt 拼接两次；保存角色和原始文本，不破坏代码缩进。

处理顺序：

1. 按 prompt_id 和规范化文本检查重复与跨划分重叠。用于查重的规范化至少固定 Unicode 与首尾空白规则；不悄悄改变训练正文。保留去重日志。
2. 保持官方 `test_prefs` 作为测试来源，从 `train_prefs` 按 prompt 划出开发集；清理跨 split 重复后，同一 prompt 不能出现在多个 split。
3. 首轮每个 prompt 一对。若出现多个记录，使用与评分无关的固定 hash 规则选一条。
4. 按固定种子随机交换两个回答一次并保存顺序。之后评分、投票和训练使用同一顺序；不要根据分数重新把较好回答排到第一位。
5. 检查空回答、重复回答、角色结构和两侧完整序列长度。删除相同回答的无效 pair；其他过滤规则预先固定并记录原因。
6. 用策略 tokenizer 和教师 tokenizer 分别检查各自模板下的 token 长度。两侧文本完整容纳后再做评分。首轮优先过滤超长样本，不对已经标注的完整回答静默截断。

建议 pilot：训练 2,000 对、开发 200 个 prompt、测试 500 个 prompt。正式规模可使用过滤后训练余量，开发目标 2,000、测试为过滤后官方测试集；在查看方法测试成绩之前冻结规模。小规模测试结果只能作为 pilot，正式结论使用预留的未用于改方案的测试部分或另设独立测试。

策略序列长度首轮候选为 2,048 tokens，指一条 prompt 加一条回答的模板化序列。若资源不允许，所有方法统一改为 1,024，并重新执行长度筛选与数据清单；不要只缩短某个方法。不同 tokenizer 的同一个数值上限不表示看到同样多的文本，应核对实际文本是否完整。

## 4 教师适配检查与 oracle 概率

主候选：[Skywork Reward V2 Llama 3.1 8B](https://huggingface.co/Skywork/Skywork-Reward-V2-Llama-3.1-8B)。官方示例使用单个原始 `logits` 作为奖励，推荐不超过 16,384 tokens，使用聊天模板时不加入 system prompt。按该模型的官方模板处理 BOS、padding 和 attention mask，并固定模型及 tokenizer revision。

先取 500–1,000 个训练 pair 做适配检查：输出分数、分差、长度分布和截断比例；抽查不同任务、明显质量差异、长短差异大的回答。原始 chosen 标签仅作诊断参考，其一致率不是新 oracle 的定义。检查 batch 与单条评分在数值容差内一致，交换两回答不改变各自分数。记录重复评分的数值波动。

冻结 RM，启用 eval/inference 模式；不训练 RM。相同文本重复评分不产生新的投票。评分缓存至少包含文本 hash、模型 revision、tokenizer、模板、精度和评分字段。Skywork 取原始标量，不分别 sigmoid 两个奖励后再求 BT 概率；若使用 ArmoRM，取官方 `output.score`，不自行平均其多个属性输出。[ArmoRM 接口](https://huggingface.co/RLHFlow/ArmoRM-Llama3-8B-v0.1)

定义：

\[
u_{i1}=r_\phi(x_i,y_{i1}),\quad u_{i2}=r_\phi(x_i,y_{i2}),\quad
p_i^*=\sigma((u_{i1}-u_{i2})/T_{\rm pref}).
\]

首轮尺度规则：对最终训练清单的非零绝对分差取中位数，令 T_pref 等于该中位数。它使中位数分差的较优回答概率约为 0.731。该规则是模拟环境设计，不是对真实人类投票的概率校准。若分差全零或小到主要反映数值误差，应排查评分，而不是任意加一个很小的温度继续跑。

在最终训练清单和教师确定后，只估计一次温度，并原样用于 dev/test。不得按每个 batch、split 或方法分别标准化奖励；不得根据 TRO 的测试成绩改温度。记录 p* 的直方图和接近 0.5、接近 0/1 的比例。允许 p*<0.5。

T_pref、DPO beta、生成 temperature、KL 半径 rho、TRO lambda 各自独立命名。切换教师或温度会改变模拟环境，需要重新构造 p*、投票和 oracle policy；只换评测 RM 是另外的跨评委评测。

## 5 模拟标注与数据接口

令 Z_it=1 表示第 t 位模拟标注者偏好 y_i1，0 表示偏好 y_i2。给定 p_i*：

\[
Z_{it}\overset{iid}{\sim}\operatorname{Ber}(p_i^*),\quad
k_i=\sum_{t=1}^{n_i}Z_{it}\sim\operatorname{Binomial}(n_i,p_i^*),\quad
\hat p_i=k_i/n_i.
\]

混合标注量主场景：n_i 属于 {5,10,20,100}，尽量等量随机分配，与教师分差、文本长度和来源独立。对每个重复实验，所有方法共享同一批 pair、n_i、k_i。每条数据仍只是一对回答，不复制成 n_i 个训练样本。

保存以下分离文件或等价表：

| 文件 | 字段 | 读取范围 |
|---|---|---|
| `pairs/{split}.jsonl` | pair_id、prompt_id、prompt/messages、response_1、response_2、原始来源、固定顺序、文本 hash | 所有方法 |
| `observations/{scenario}/{repeat}/train.jsonl` | pair_id、n_votes、k_1、p_hat、hard_label、采样 seed | 所有普通训练方法 |
| `oracle/{split}.jsonl` | pair_id、score_1、score_2、p_star、teacher 与温度标识 | 模拟器、oracle 训练、受控诊断 |
| `uncertainty/{config}/{repeat}.jsonl` | pair_id、rho_i、lower、upper、lambda_i、置信统计 | 对应 DRO/TRO 方法 |
| `manifests/*.json` | 数据/model revision、过滤清单、配置、代码提交、hash、seed | 复现和审计 |

普通 trainer 的 batch 不包含 p_star 或教师分数；通过明确字段白名单测试这一点。Oracle trainer 才能载入 p_star。训练集之外的 RM 验证用于同等模型选择，不把验证信息反向写入训练标签。

记录独立种子：split、顺序、n_i 分配、投票、训练、生成。可按 pair_id 和 seed 派生局部随机数，保证并行顺序不改变模拟数据。不要使用进程随机化的 Python hash 作为持久种子。

对于 n 增长实验，可为同一 pair 预生成最长 Bernoulli 序列，用前 n 票构造嵌套观测；每个 n 的边际分布仍正确，场景间相关性需在统计中保留。主实验无须保存每一票，但必须能由 seed 重建计数。

## 6 所有方法共享的 DPO 定义

初始策略 pi_0 和冻结参考 pi_ref 使用同一个基座 checkpoint。定义序列 log probability 为回答 token 的条件 log probability 之和；排除 prompt 和 padding，EOS 是否计入采用统一记录的规则，不改成按回答长度平均。

\[
z_i(\theta)=\beta\left[
\log\frac{\pi_\theta(y_{i1}|x_i)}{\pi_{\rm ref}(y_{i1}|x_i)}-
\log\frac{\pi_\theta(y_{i2}|x_i)}{\pi_{\rm ref}(y_{i2}|x_i)}\right],
\quad q_i(\theta)=\sigma(z_i(\theta)).
\]

q_i 是策略相对于参考模型隐含的二元偏好概率，不是生成 y_i1 的归一化概率。软标签损失为：

\[
\ell_i(\theta,p)=-p\log\sigma(z_i)-(1-p)\log\sigma(-z_i)
=\operatorname{softplus}(z_i)-pz_i.
\]

外层始终为：

\[
L(\theta)=\frac1N\sum_{i=1}^{N}L_i(\theta).
\]

| method_id | 每对损失 | 说明 |
|---|---|---|
| `hard_dpo` | ell(z_i,h_i) | h_i 为多数票方向；平票用固定随机方向，不删样本 |
| `soft_dpo` | ell(z_i,p_hat_i) | 核心 empirical 基线 |
| `label_dro_common` | sup_{p in U_i(rho)} ell(z_i,p) | 所有题使用同一 KL 半径 |
| `tro_common` | (1-lambda_i)ell(z_i,p_hat_i)+lambda_i sup_{p in U_i(rho)}ell(z_i,p) | 同一基础半径，逐题折中 |
| `oracle_soft_dpo` | ell(z_i,p_star_i) | 信息充分参照 |
| `label_dro_n` | sup_{p in U_i(rho_i)}ell(z_i,p) | 标注量自适应半径的更强对照 |
| `tro_n` | 与 TRO 相同，集合改为 U_i(rho_i) | 与 label_dro_n 共用同一集合，隔离折中效果 |

这里的 `label_dro_common` 是为本实验明确构造的标签 DRO 基线，不未经核验就称为某篇论文的精确复现。旧 KLDPO/WDPO 不是上述方法的可直接替代实现。

把每一票的硬标签损失先在题内平均，恰好等于 soft DPO：

\[
\frac{k_i\ell(z_i,1)+(n_i-k_i)\ell(z_i,0)}{n_i}=\ell(z_i,\hat p_i).
\]

若所有票全局平均，则权重变成 n_i/sum_j n_j。该做法只能作为单独的 `vote_weighted_soft_dpo` 对照，不能悄悄替代 1/N。

实现该额外对照时，若仍均匀采样 pair，应使用全训练集预先计算的权重 N*n_i/sum_j n_j 再对 batch 平均。不要每个 minibatch 临时除以该 batch 的票数和，否则随机分母会改变目标估计。

## 7 KL 球和逐题可靠性规则

主实现取以下明确方向：

\[
\mathcal U_i(\rho_i)=\{p\in[0,1]:d_{\rm KL}(\hat p_i\Vert p)\le\rho_i\},
\]

\[
d_{\rm KL}(a\Vert p)=a\log(a/p)+(1-a)\log((1-a)/(1-p)).
\]

所有对抗变量都是每题的 p_i。名义联合分布为 P_0(s,Z)=(1/N)sum_i delta_{s_i}(s) Ber_{p_hat_i}(Z)。集合是每题集合的乘积；题与题之间不共享一个对抗预算，但仍共享神经网络参数。

**统一半径主比较**：rho_i=rho。首轮示例 rho=0.05，它不是统计意义的统一 95% 置信球，必须给 DRO 提供调半径机会。

**按标注量的增强对照**：

\[
\rho_i=\eta\,\frac{\log((n_i+1)/\delta)}{n_i},\qquad\delta=0.05.
\]

eta=1 时，独立二项抽样的类型概率界给出每题覆盖至少 1-delta：Pr[d_KL(p_hat_i||p_i*)>rho_i] <= (n_i+1)exp(-n_i rho_i)=delta。不是所有题同时 95%，也不是模型奖励保证。eta 不等于 1 的调参版本不沿用该覆盖声明。

初版逐题折中明确采用：

\[
\lambda_i=\frac{n_0}{n_i+n_0},\qquad n_0\ge0.
\]

n_0=10 时，n_i=5、10、20、100 对应 lambda_i=2/3、1/2、1/3、1/11。n_0=0 为 soft DPO；n_0 为无穷时显式设 lambda=1，为同集合 DRO。

该规则把标注量转成保守程度，是透明的首轮候选，不是校准的“标签正确概率”。它先隔离标注量的作用；p_hat 仍通过名义损失、KL 球形状和球端点影响训练。后续可增加基于二项置信区间宽度的 lambda 规则，不能无标识地替换主规则。

同时报告由票数构造的置信区间宽度。例如用上面的 eta=1 统计球求端点 A_i,B_i，报告 w_i=B_i-A_i。大量 50:50 投票可以准确估计人群偏好接近 0.5；不能仅凭接近 0.5 就定义低置信。5/5 也不是完全确定，不能使用端点处方差为零的朴素 Wald 区间。

KL 方向不可反转：d_KL(p||p_hat) 在 p_hat=0/1 时有支持退化。本协议方向有闭式边界：

\[
\hat p=0:\ [a,b]=[0,1-e^{-\rho}],\qquad
\hat p=1:\ [a,b]=[e^{-\rho},1].
\]

当 0<p_hat<1，在 [0,p_hat] 和 [p_hat,1] 分别二分求根 d_KL(p_hat||p)=rho。rho=0 直接返回 [p_hat,p_hat]。端点使用 float64 离线求解；记录容差并检查包含中心，不用训练时的近似内层梯度上升。

## 8 精确损失实现与零点次梯度

KL 球在二元概率单纯形上是一维区间 [a_i,b_i]。求区间端点是在精确计算该球，不是把 KL 任意换成欧氏区间。

\[
p_i^{\rm worst}=
\begin{cases}
a_i,&z_i>0,\\
b_i,&z_i<0,\\
\hat p_i,&z_i=0.
\end{cases}
\]

零点处任意球内概率均为最大化解；本协议明确选择中心以确定初始梯度。不要使用 `maximum` 的默认平票梯度后又假定它一定等于中心次梯度。

\[
t_i=(1-\lambda_i)\hat p_i+\lambda_i p_i^{\rm worst},\quad
L_i^{\rm TRO}=\ell(z_i,t_i),\quad
\nabla_\theta L=\frac1N\sum_i(\sigma(z_i)-t_i)\nabla_\theta z_i.
\]

t_i 依赖当前 margin 符号，不能预先保存成一个固定 soft label。球端点和 lambda 来自观测数据；计算最坏概率和 t_i 时停止梯度。

核心 PyTorch 形式如下，接入时另处理有效样本 mask 和分布式平均：

```python
z = beta * ((logp_1 - logp_ref_1) - (logp_2 - logp_ref_2))
z = z.float()
with torch.no_grad():
    worst = torch.where(z > 0, lower,
                        torch.where(z < 0, upper, p_hat))
    target = (1 - lam) * p_hat + lam * worst
per_pair = -target * F.logsigmoid(z) - (1 - target) * F.logsigmoid(-z)
loss = per_pair.mean()  # 仅在有效样本数和累积缩放正确时直接使用
```

这段前向数值就是实际 TRO 目标，不需要代理前向数值。验证等价展开式：

\[
L_i^{\rm TRO}=\ell(z_i,\hat p_i)+\lambda_i[(\hat p_i-a_i)(z_i)_+ +(b_i-\hat p_i)(-z_i)_+].
\]

实现不存在全 batch 的 exp(loss/tau)、softmax 样本权重或相应归一化常数；不继承旧 KLDPO 的权重截断。参考模型初始等于策略时 z_i 应接近 0，但梯度通常不为零，应检查这种情形。

示例中的四个序列 logprob 应先用 float32 累加并保持 float32 后再相减；不能先在 BF16 中累加长序列、相减丢失精度后，指望最后一行 `.float()` 恢复信息。确定性初始 z 检查须统一模型的 dropout 设置和计算路径。

## 9 公平训练与超参数选择

首轮候选底座 `meta-llama/Llama-3.2-1B-Instruct`，优先复用已有干净基座缓存，记录准确 revision。若更换底座，所有方法共同更换并重新训练 oracle。

候选工程默认：全参数训练、BF16、2 epochs、有效 batch 128 对、学习率 5e-7、beta=0.01、AdamW betas=(0.9,0.95)、weight decay=0、warmup ratio=0.1、gradient clip=1.0、梯度检查点。它们仅为复用旧工程的起点；若需要 LoRA 或其他设置，所有方法统一并在查看最终测试前冻结。

共同控制：初始化、参考模型、tokenizer、数据清单、最大长度、EOS/mask、优化器、学习率日程、更新次数、有效 batch、checkpoint 规则和生成规则。先检查 soft/oracle 的学习曲线和梯度是否正常；不要因 TRO 是否领先来选择实现或种子。

日志至少记录名义损失、鲁棒增量、margin 的均值与绝对值、clip 前梯度范数、参数更新量、lambda 分布、区间宽度及跨过 0.5 的比例。若所有方法几乎不更新，应先排查 mask、梯度缩放、优化步数和学习率，再解释鲁棒性结果；所有修订统一应用于相同实验组并记录。

规则 batch 情况下 B_effective=microbatch_per_rank × data_parallel_world_size × accumulation_steps。不要把 tensor parallel 数当 data parallel 数。每个 microbatch 可以 backward，累计期间模型参数保持不变，到 optimizer.step 才更新；不得重复除 accumulation steps。最后不足整批的样本和 DDP padding 要按实际有效对数正确加权，验证分布式结果与同一大 batch 的梯度一致。

若框架默认各 rank 梯度平均，而各 rank 的有效数不同，单次更新应实现全局有效样本均值；不能简单平均各卡局部均值。让接手 agent 按框架已有缩放机制验证，避免盲目再乘 world_size。新损失逐题可加，不需要 all_gather losses。

最大步数由真实数据长度、采样规则和有效 batch 推导，不能沿用旧实验的 global_step158。首轮所有方法训练相同 epochs 并比较最终 checkpoint；若后来采用 checkpoint 选择，统一候选时点和开发集选择规则。

首轮搜索建议各族最多 6 个配置，重复端点可复用：

| 方法族 | 搜索 |
|---|---|
| 统一半径 DRO | rho in {0,0.001,0.005,0.01,0.05,0.1} |
| TRO common | 固定基础 rho=0.05，n_0 in {0,5,10,20,50,infinity} |
| 按 n 调半径 DRO | eta in {0,0.1,0.25,0.5,1,2} |
| TRO n | 固定 eta=1、delta=0.05，同样 6 个 n_0 |

同时报告同集合的 lambda=1 对照和调好半径的 DRO。主结论不能只比较 TRO 与一个任意大半径的 DRO。若扩展网格或给 TRO 同时调 rho 与 n_0，应给基线可比的搜索预算并报告总运行次数；不要把搜索最佳点落在边界的问题隐藏起来。

开发集使用同一冻结 RM 对生成回答评分，按平均奖励选择配置。所有方法获得相同验证信息；可以查看辅助偏好风险解释现象，但不事后切换主选择指标。对主方法预先用独立的开发投票 seed 做选择，随后固定配置，在新的标签/训练重复上做最终比较。教师验证不是完全无标签的训练设定，应在文章中说明。

## 10 主评测和辅助指标

固定 M 个测试 prompt，各模型每题独立生成 K=10 个回答。统一 temperature=0.7、top_p=0.9、max_new_tokens=1024、repetition_penalty=1.0、EOS 和停止规则。先验证策略 context 能容纳完整 prompt 加最大生成长度；首轮候选 generation context=4096，必须服从真实模型支持范围。教师以自己的 tokenizer 检查完整生成文本，记录超长和到达生成上限的比例，不静默截断后继续当完整评分。

同一冻结 RM 给每个新回答评分，所有回答均计入平均，不做 best-of-K：

\[
\bar r_{mj}=\frac1K\sum_{k=1}^K r_\phi(x_j,y_{mjk}),\quad
\widehat V_m=\frac1M\sum_{j=1}^M\bar r_{mj},\quad
\widehat{Gap}_m=\widehat V_{\rm oracle}-\widehat V_m.
\]

同时报告 V 和 Gap。正 Gap 表示落后；接近零表示平均生成奖励接近；负值表示超过这次 oracle 或存在抽样波动，不能裁剪为零。Oracle 是有限模型与优化下的参照，不是理论上界。不以奖励比值作为恢复率，因奖励零点可任意。

必要辅助指标：

\[
R^*(\theta)=\frac1{N_{\rm test}}\sum_i\ell(z_i(\theta),p_i^*),\quad
\Delta R^*=R^*(\theta_m)-R^*(\theta_{\rm oracle}).
\]

再报告 q_i 与 p_i* 的均方误差，以及 R* 减去平均二元熵 H(p*) 的 excess log loss。它等于测试 pair 上 KL(Ber(p*)||Ber(q)) 的平均，优先通过稳定的 logsigmoid 计算，不对已经饱和的 q 直接取 log。固定测试回答对来自保留的 UltraFeedback test pair，不需要从训练策略的 rollout 中重新挑对。

生成奖励与 pair 风险回答不同问题；相同平均奖励不证明偏好概率或生成分布相同。另报告回答长度、空回答、重复、达到 token 上限的比例。可按测试 p* 强度分组作离线诊断；不要给测试题随机分配 n_i 后把它当作模型训练时的可靠性信息。

## 11 重复实验与统计

pilot 至少 3 组不同投票与训练随机性；正式优先 5 组或以上，并按资源和方差说明。每组内所有方法共享观测数据，训练 seed 配对；不同 seed 的重复生成不能替代重新采样标签和重新训练。

开发选参 seed 与最终重复分离。分别记录标签随机性、训练随机性、生成随机性；若一组编号绑定三者，结论是联合重复性，不声称已分解各个方差来源。

默认主实验固定 n_i 的随机分配，只重抽投票并改变训练/生成 seed，因此重复性结论条件于该分配。改变 n_i 分配的实验另列；不要把同一个固定 allocation seed 描述为重复随机分配。

Oracle 不依赖 n_i/k_i。同样文本、p*、训练配置和训练 seed 下，可以跨标注场景复用 oracle，但不能把复用结果当新增独立样本。初始 pi_0 的生成奖励也保存作诊断。

对一次运行的奖励差，以 prompt 为单位做配对 bootstrap，保留每题 K 个回答成组。跨运行报告每次 Gap、均值、标准差和方法间配对差；少数重复不要宣称稳定的 95% 尾部风险。Prompt bootstrap 只描述测试抽样/生成波动，不覆盖重新标注和训练的不确定性。

## 12 必须支持的实验矩阵

| 场景 | 设置 | 目的 |
|---|---|---|
| 混合标注量 | n_i=5、10、20、100 等量分配 | 主实验：可靠性异质 |
| 标注量增长 | 所有题 n=5、10、20、50、100，可扩展 500 | 比较向 oracle 靠近的趋势 |
| 同预算比较 | 主混合均值 33.75，对照 1/4 题 33 票、3/4 题 34 票 | 区分总预算与分配异质性 |
| 固定 lambda | 相同集合、所有题同一个 lambda，开发集调参 | 区分全局折中与逐题折中 |
| 打乱可靠性 | 真实 k,n,p_hat 和集合不变，只置换 lambda 所读取的 n | 检验可靠性是否用在正确的题上 |
| 按 n 调半径 | label_dro_n 与 tro_n | 判断简单自适应半径是否已经足够 |
| 简单统计对照 | vote-weighted soft DPO；可增加 Beta 平滑 soft DPO | 排查重加权或普通平滑能否解释收益 |
| 第二教师 | 换 ArmoRM，重新构造整个 oracle 与投票链路 | 检验结论是否依赖一个模拟教师 |

Beta 平滑若加入，明确 p_tilde=(k+c)/(n+2c)，c 由开发集调参；它是额外基线，不自动替换 empirical soft DPO。若声称优于 DPO-PRO 或 VDPO，另行核验对应论文/代码和命名，不能把本协议通用基线直接贴上原论文名称。

固定 n 的增长实验中，同一个 n 规则给所有题相同 lambda；它检验有限标注趋势，不单独证明逐题异质机制。沿用混合场景选择的 n_0 观察预先规定的渐近趋势，另列逐 n 重新调参结果，二者不能混用。

额外噪声作为独立扩展：每票以 epsilon 翻转，则 p_obs=epsilon+(1-2epsilon)p*。普通二项区间此时估计 p_obs；n 增大不会自动恢复 p*。该实验必须单列为污染压力测试；若做噪声校正，需要可识别的噪声信息以及各方法相同的信息权限。

## 13 理论解释的边界

本目标等价于在收缩集合上做 DRO：

\[
\widetilde{\mathcal U}_i=(1-\lambda_i)\hat p_i+\lambda_i\mathcal U_i,
\quad L_i^{\rm TRO}=\sup_{p\in\widetilde{\mathcal U}_i}\ell(z_i,p).
\]

因此可以研究相对于“所有题共用同一半径”的方案的严格扩展，但不能声称任意数据相关集合的 DRO 都无法表示 TRO。

一个可核验的区分例子采用 chi-square 球，而不是把 KL 结果冒充成 chi-square 结果：两题经验概率都为 0.7，票数分别 7/10、70/100，集合满足 (p-0.7)^2/(0.7*0.3)<=1/21，因此均为 [0.6,0.8]。取 n_0=10，lambda 分别 1/2 和 1/11，收缩区间的下端分别为 13/20 与 38/55。若两题 margin 可独立优化，最优 q 分别为这两个不同值。

任何统一半径的同族 DRO，因为两题中心相同且损失结构相同，最优 q 两维相同，无法得到该联合解。允许每题不同半径时，rho_eff_i=lambda_i^2/21 即可复现，所以例子只针对统一半径类。LLM 共享参数的可达解与泛化收益还需实际验证，不能用独立 margin 的例子代替。

标注量收敛也有明确条件。固定有限 N，若所有 n_i 趋于无穷，p_hat_i 几乎必然趋于 p_i*；固定有限 n_0 时 lambda_i 趋于零。若考察的模型类满足 |z_i(theta)|<=C，则

\[
\sup_\theta|L_{\rm TRO}(\theta)-L_{\rm oracle}(\theta)|
\le \frac C N\sum_i(|\hat p_i-p_i^*|+\lambda_i)\to0.
\]

证明来自 ell 对 p 的线性性、概率差最多为 1，以及大数定律。该结论是固定训练 pair 上的目标一致性；要推出最优参数收敛，还需紧致性、可识别或唯一解及优化条件。有限步神经网络训练不自动满足，也不保证生成奖励逐 n 单调。Soft DPO 同样一致；TRO 的有限样本优势是要通过实验检验的偏差与方差折中，不是预先成立的定理。

## 14 实现验收与运行顺序

数学验收：

- soft loss 等于题内逐票平均；比较值与梯度。
- lambda=0 等于 soft；lambda=1 等于同集合 DRO；rho=0 等于 soft。
- 球端点包含中心，内部中心的两端 KL 等于 rho；端点中心使用闭式。
- 最坏端点与密集一维搜索一致；TRO 混合式、有效标签式、展开式和收缩集合式一致。
- 交换两回答，p_hat 变为 1-p_hat、z 变为 -z、区间变为 [1-b,1-a] 后值相同、对应 margin 梯度反号。
- p_hat=0/1、z=0、极端 margin 均数值稳定；零点次梯度为 0.5-p_hat。
- toy chi-square 例子产生不同联合解；不把它当作 LLM 效果实测。

工程验收：

- 按 prompt 检查 split 隔离、每侧文本与原始记录一致；所有方法读取同一文本和票数 hash。
- 普通 trainer 无 p*；参考策略冻结；logprob mask 只包含回答 token。
- RM 单条/批量一致、完整文本、输出字段正确、模板不重复 BOS。
- 少量真实序列验证 z 的值与手工计算；同一初始/参考模型时 z 接近零。
- 梯度累积、不同 microbatch 和多卡与同一有效大 batch 对照，检查缩放及末尾样本。
- 同一测试 prompt 每个模型恰有 K 条唯一编号输出；评分失败可重试同一回答，不得重新生成直到得到高分；最终仍失败应报告，不能默默删除。
- 从原始逐回答文件重算聚合指标，验证差距符号、测试题数、重复 seed 与 bootstrap 单位。

运行顺序：先执行包内 `reference_math.py`；实现并测试新 loss 和数据接口；在约 100 对真实文本上完成评分、模拟、训练数步、生成及评测的端到端检查；再运行 2,000 对的 pilot 和开发集搜索；冻结配置后完成预定重复与实验矩阵。资源不足时保留可执行实现、实际完成的检查、资源估算和下一条命令，不编造完成状态。

训练前生成 `resolved_config.json`，所有 revision、实际长度、microbatch、设备拓扑、tokenizer、模板、种子必须具体化。配置中的 null 表示尚待环境解析，不允许最终实验静默使用可变的 `main` revision。

## 15 接手 agent 的交付物

1. 环境扫描报告、实际版本、资源与代码修改映射。
2. 固定数据 manifest、长度与去重报告、RM 适配检查和分差/p* 分布。
3. 分离的 oracle 与普通观测数据、投票生成器、可重建的随机种子。
4. 七个 method_id 的损失/训练入口，至少核心五组的端到端命令；补充对照按矩阵提供配置。
5. 数学、数据隔离、token mask、梯度累积和聚合统计的验证结果。
6. 每次实际运行的配置、日志、checkpoint、逐回答生成与分数、逐 prompt 汇总。
7. 汇总表：method、scenario、repeat、n 规则、rho 规则、lambda 规则、平均 reward、oracle Gap、真实偏好风险、长度、训练步数、运行成本。
8. 结论与失败分析：是否超过 soft、调参 DRO；是否只优于过度保守的固定设置；标注量变化是否符合预期；未完成项目与原因。

不得以挑选 TRO 获胜的 seed、评分维度、测试子集或温度代替预定比较。若 lambda=0 最好、若自适应半径 DRO 已能达到相同效果，完整报告。这些结果决定能够支持的贡献范围。
