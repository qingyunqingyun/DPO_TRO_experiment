# DPO TRO 实验交接包

日期：2026-10-26。供合作者及其 agent 扫描现有工程、构造数据、实现训练和评测使用。

首先读取 `EXPERIMENT_PROTOCOL.md`，再读取 `experiment_config.json`。配置中的数值是首轮工程默认值，不是已经验证的最优参数。模型和数据的 revision 必须在运行环境中解析成确定的提交版本并保存；GPU 数量和 microbatch 由实际资源确定。

核心链路：UltraFeedback 固定回答对 → 冻结 RM 重新评分 → BT 定义真实概率 p* → 按不同 n_i 模拟投票 → 硬 DPO、empirical soft DPO、标签 DRO、逐题 TRO 与 oracle soft DPO → 相同测试问题多次生成 → 同一 RM 评分并比较 oracle 差距。

包内文件：

- `EXPERIMENT_PROTOCOL.md`：完整数学定义、数据接口、训练公平性、评测、消融和验收条件。
- `experiment_config.json`：机器可读的候选配置与搜索范围。
- `reference_math.py`：只依赖 Python 标准库的数学参考与自检；不是 LLM trainer，也不下载模型。
- `VALIDATION.md`：本交接包实际完成的核验，以及仍须在接手环境完成的检查。

先运行：

```bash
python3 reference_math.py
```

接手 agent 的首批工作是扫描仓库和资源、实现新数据接口及新损失、完成小规模端到端检查，并输出可执行命令与环境清单。按协议在现有资源范围内推进实验；不要仅返回摘要。不得把尚未运行的模型训练或评测写成已完成。

本包中的协议是本次新实验的执行规格。历史文档可供参考，但其中 HelpSteer2 自行生成训练候选、后验均值作为主标签、全局 loss 重加权以及只以固定回答对风险为主指标的设定，不是本实验默认值。仓库里的访问控制、只读目录和用户指令仍按原规则遵守。
