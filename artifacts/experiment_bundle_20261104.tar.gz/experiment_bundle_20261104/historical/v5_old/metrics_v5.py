#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from collections import defaultdict
from pathlib import Path
import numpy as np

def grouped(path):
 out=defaultdict(list)
 for line in Path(path).open():
  if line.strip():
   r=json.loads(line); out[r['prompt_id']].append(float(r['skywork_score']))
 return out

def main():
 p=argparse.ArgumentParser(); p.add_argument('--oracle',required=True); p.add_argument('--input',nargs='+',required=True); p.add_argument('--output',required=True); p.add_argument('--bootstrap',type=int,default=2000); p.add_argument('--seed',type=int,default=601); a=p.parse_args()
 o=grouped(a.oracle); keys=sorted(o); ov=np.array([np.mean(o[k]) for k in keys],dtype=float)
 rng=np.random.default_rng(a.seed); results=[]
 for spec in a.input:
  name,path=spec.split('=',1); g=grouped(path); mv=np.array([np.mean(g[k]) for k in keys],dtype=float)
  diff=mv-ov; idx=rng.integers(0,len(keys),size=(a.bootstrap,len(keys))); boots=diff[idx].mean(axis=1)
  results.append({'method':name,'prompts':len(keys),'samples':sum(len(g[k]) for k in keys),'mean_reward':float(mv.mean()),'oracle_mean_reward':float(ov.mean()),'method_minus_oracle':float(diff.mean()),'absolute_mean_reward_gap':float(abs(mv.mean()-ov.mean())),'mean_absolute_prompt_gap':float(np.abs(diff).mean()),'paired_bootstrap_ci95_method_minus_oracle':[float(np.quantile(boots,.025)),float(np.quantile(boots,.975))]})
 out={'oracle_samples':sum(len(o[k]) for k in keys),'oracle_mean_reward':float(ov.mean()),'bootstrap_replicates':a.bootstrap,'bootstrap_seed':a.seed,'results':results}
 Path(a.output).parent.mkdir(parents=True,exist_ok=True); Path(a.output).write_text(json.dumps(out,indent=2)+'\n'); print(json.dumps(out,indent=2))
if __name__=='__main__': main()
