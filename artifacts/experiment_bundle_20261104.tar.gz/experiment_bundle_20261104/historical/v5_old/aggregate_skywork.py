#!/usr/bin/env python3
import argparse,json,math
from collections import defaultdict
from pathlib import Path

def main():
 p=argparse.ArgumentParser(); p.add_argument('--input',required=True); p.add_argument('--output',required=True); p.add_argument('--rollouts-per-prompt',type=int,default=10); a=p.parse_args()
 groups=defaultdict(list)
 for line in Path(a.input).open():
  if line.strip():
   r=json.loads(line); groups[json.dumps(r['prompt'],ensure_ascii=False,sort_keys=True)].append(r)
 counts=sorted({len(v) for v in groups.values()})
 if counts != [a.rollouts_per_prompt]: raise ValueError(f'rollout counts {counts}')
 vals=[]
 for rows in groups.values(): vals.append(sum(float(r['skywork_score']) for r in rows)/len(rows))
 mean=sum(vals)/len(vals); var=sum((v-mean)**2 for v in vals)/max(1,len(vals)-1)
 out={'num_prompts':len(groups),'rollouts_per_prompt':a.rollouts_per_prompt,'aggregation':'mean within prompt then mean over prompts','skywork_mean_reward':mean,'std_prompt_mean':math.sqrt(var),'ci95':1.96*math.sqrt(var/len(vals)),'min_prompt_mean':min(vals),'max_prompt_mean':max(vals),'min_response':min(float(r['skywork_score']) for rows in groups.values() for r in rows),'max_response':max(float(r['skywork_score']) for rows in groups.values() for r in rows)}
 Path(a.output).parent.mkdir(parents=True,exist_ok=True); Path(a.output).write_text(json.dumps(out,indent=2)+'\n'); print(json.dumps(out,indent=2))
if __name__=='__main__': main()
