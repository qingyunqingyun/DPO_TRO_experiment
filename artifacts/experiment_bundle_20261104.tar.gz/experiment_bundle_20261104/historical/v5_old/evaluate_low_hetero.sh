#!/usr/bin/env bash
set -euo pipefail
REPO=/mnt/hezhisheng/distributionally_robust_dpo-2
V5=/mnt/hezhisheng/su/experiment_handoff_v5
PY="$REPO/.venv/bin/python"
MODEL="$REPO/models/Llama1b"
RM="$V5/models/Skywork-Reward-V2-Llama-3.1-8B"
mkdir -p "$V5/eval" "$V5/logs"
methods=(hard_dpo soft_dpo label_dro_common tro_trust_common oracle_soft_dpo)
for method in "${methods[@]}"; do
  ckpt="$V5/outputs/low_heterogeneous_seed101_$method/final_hf"
  out="$V5/eval/low_heterogeneous_seed101_$method"
  mkdir -p "$out"
  if [[ ! -f "$ckpt/model.safetensors" ]]; then echo "missing checkpoint $ckpt" >&2; exit 1; fi
  if [[ ! -f "$out/generations.jsonl" ]] || [[ "$(wc -l < "$out/generations.jsonl")" -ne 5000 ]]; then
    rm -f "$out/generations.jsonl"
    CUDA_VISIBLE_DEVICES=4 "$PY" "$REPO/scripts/tro_generate_eval.py" --model "$ckpt" --pairs "$V5/data/pairs/test_diagnostic.jsonl" --output "$out/generations.jsonl" --k 10 --seed 401 --max-new-tokens 256 --temperature 0.7 --top-p 0.9 --gpu-memory-utilization 0.85 2>&1 | tee "$V5/logs/generate_${method}.log"
  fi
  if [[ ! -f "$out/scored.jsonl" ]] || [[ "$(wc -l < "$out/scored.jsonl")" -ne 5000 ]]; then
    rm -f "$out/scored.jsonl"
    # A single 8B reward-model forward at the pilot's 2048-token context is
    # stable on the available 80 GiB card; larger padded batches can OOM.
    CUDA_VISIBLE_DEVICES=1 "$PY" "$V5/score_skywork.py" --model "$RM" --input "$out/generations.jsonl" --output "$out/scored.jsonl" --mode responses --batch-size 1 --max-length 4096 --device cuda:0 2>&1 | tee "$V5/logs/score_generated_${method}.log"
  fi
done
specs=()
for method in "${methods[@]}"; do specs+=("$method=$V5/eval/low_heterogeneous_seed101_$method/scored.jsonl"); done
"$PY" "$V5/metrics_v5.py" --oracle "$V5/eval/low_heterogeneous_seed101_oracle_soft_dpo/scored.jsonl" --input "${specs[@]}" --output "$V5/eval/low_heterogeneous_metrics.json" --bootstrap 2000 --seed 601
