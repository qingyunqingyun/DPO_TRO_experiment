# v5 pilot report: Skywork RM with $N_i\in\{1,3,5,7,9\}$

Generated: 2026-10-27  
Experiment directory: `/mnt/hezhisheng/su/experiment_handoff_v5`  
Scenario: `low_heterogeneous`  
Protocol: `2026-10-27-v5-trust`

## Summary

This pilot uses the local Llama 3.2 1B policy and the frozen `Skywork/Skywork-Reward-V2-Llama-3.1-8B` reward model. The five annotation-count levels are balanced: `N_i={1,3,5,7,9}`. Every trained method ran for two epochs. Evaluation contains 500 prompts and 10 sampled responses per prompt (5,000 responses per method).

Among the methods trained in this v5 pilot, `tro_trust_common` is closest to the Skywork-based oracle by point estimate. Its mean reward is `0.893529`, compared with the oracle's `0.990348`, for a method-minus-oracle gap of `-0.096818`. `label_dro_common` is second closest (`-0.126591`). `hard_dpo` and `soft_dpo` are lower (`-0.234265` and `-0.216814`). The oracle row is a reference trained from Skywork-derived `p*`; it is not an independent human upper bound.

| Method | Mean Skywork reward | Method − oracle | Absolute gap | Paired bootstrap 95% CI |
|---|---:|---:|---:|---:|
| `oracle_soft_dpo` | 0.990348 | 0.000000 | 0.000000 | [0.000000, 0.000000] |
| `tro_trust_common` | 0.893529 | -0.096818 | 0.096818 | [-0.348993, 0.139279] |
| `label_dro_common` | 0.863757 | -0.126591 | 0.126591 | [-0.361719, 0.117504] |
| `soft_dpo` | 0.773534 | -0.216814 | 0.216814 | [-0.427741, -0.015738] |
| `hard_dpo` | 0.756082 | -0.234265 | 0.234265 | [-0.457105, -0.009155] |

The intervals are paired-prompt bootstrap intervals for method minus oracle, with 2,000 replicates and seed 601. They are wide because this is a single pilot seed and the Skywork score scale is different from the previous ArmoRM run.

## Runtime configuration

| Item | Actual setting |
|---|---|
| Policy | `meta-llama/Llama-3.2-1B-Instruct`, local `distributionally_robust_dpo-2/models/Llama1b` |
| Reward model | `Skywork/Skywork-Reward-V2-Llama-3.1-8B` |
| Reward score | Skywork sequence-classification scalar logit (`logits[:,0]`) |
| Preference temperature | `T_pref=9.21875`, median nonzero absolute train score gap |
| Train/dev/test | 2,000 / 200 / 500 fixed pair prompts; test generation 500 prompts × 10 responses |
| Annotation counts | `{1,3,5,7,9}`; train 400 per level; dev 40 per level |
| Allocation/vote seeds | 1731 / 101 |
| Trust rule | `lambda_i=N_i/(N_i+c)`, `c=10` |
| Trust weights | N=1: 0.090909; N=3: 0.230769; N=5: 0.333333; N=7: 0.411765; N=9: 0.473684 |
| Common KL radius | `rho=0.05` |
| Methods | hard DPO, soft DPO, label-DRO-common, trust-TRO-common, oracle-soft-DPO |
| Epochs / LR / beta | 2 / `5e-7` / `0.01` |
| Policy sequence length | 512 tokens (resource-constrained pilot setting) |
| Precision / optimization | BF16, gradient checkpointing, ZeRO-2, microbatch 1, batch argument 16, torch AdamW |
| Generation | seed 401, K=10, temperature 0.7, top-p 0.9, max new tokens 256, max model length 2048 |
| Generated-response RM scoring | batch size 1, max length 4096, GPU 1 |
| Bootstrap | 2,000 paired-prompt replicates, seed 601, 95% CI |

The fixed pair manifests were reused from the v3 pilot for this smoke test. All five methods have complete checkpoints, 5,000 generated responses, and 5,000 Skywork scores.

## Interpretation

The common-radius trust-TRO variant is the best point estimate in this v5 run. The bootstrap interval still crosses zero, so this pilot does not establish a statistically reliable advantage over the oracle reference. The result is useful as a screening signal for the next multi-seed run.

The raw Skywork score scale is not comparable to the previous ArmoRM scores. Cross-run comparisons should use each run's method-minus-its-own-oracle gap, and even that comparison is provisional because the reward model changed. The oracle and generated responses are evaluated by the same Skywork model, so this is a within-RM consistency test.

## Reproducibility files

- Metrics: [`eval/low_heterogeneous_metrics.json`](eval/low_heterogeneous_metrics.json)
- Runtime manifest: [`resolved_runtime_manifest.json`](resolved_runtime_manifest.json)
- Pair score files: `data/scores/`
- Oracle files: `data/oracle/`
- Observations: `data/observations/low_heterogeneous/seed101/`
- Method datasets: `datasets/low_heterogeneous/seed101/`
- Checkpoints: `outputs/low_heterogeneous_seed101_<method>/final_hf/`
- Generated responses and scores: `eval/low_heterogeneous_seed101_<method>/`
- Evaluation script: [`evaluate_low_hetero.sh`](evaluate_low_hetero.sh)

## Limitations

1. This is one pilot split, vote seed, training seed, and generation seed.
2. The policy sequence length is 512 and the training batch argument is 16 because of the available runtime budget; these are shared across methods but are below the protocol's formal candidates.
3. The test set is the reused fixed v3 pilot manifest, so this result is a smoke test rather than an independent final benchmark.
4. Only the five v5 core methods were trained; n-adaptive radius variants were intentionally excluded by the v5 README protocol.
