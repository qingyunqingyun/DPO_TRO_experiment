from __future__ import annotations
import json, shutil, subprocess, sys
from pathlib import Path
from datasets import Dataset, DatasetDict

V5 = Path('/mnt/hezhisheng/su/experiment_handoff_v5')
REPO = Path('/mnt/hezhisheng/distributionally_robust_dpo-2')
PY = REPO/'scripts'
DATA = V5/'data'
methods = ['hard_dpo','soft_dpo','label_dro_common','tro_trust_common','oracle_soft_dpo']
# The existing helper writes the audit-friendly method records; v5 semantics are
# supplied by the patched tro_math.lambda_from_n implementation.
for m in methods:
    helper_m = 'tro_common' if m == 'tro_trust_common' else m
    out = DATA/'methods'/'low_heterogeneous'/'seed101'/f'{m}.jsonl'
    cmd=[sys.executable, str(REPO/'scripts/tro_prepare_data.py'),'method-records',
         '--pairs',str(DATA/'pairs/train.jsonl'),
         '--observations',str(DATA/'observations/low_heterogeneous/seed101/train.jsonl'),
         '--output',str(out),'--method',helper_m]
    if m == 'oracle_soft_dpo': cmd += ['--oracle',str(DATA/'oracle/train.jsonl')]
    subprocess.run(cmd, check=True)
    dev_out = DATA/'methods'/'low_heterogeneous'/'seed101'/f'{m}_dev.jsonl'
    cmd=[sys.executable, str(REPO/'scripts/tro_prepare_data.py'),'method-records',
         '--pairs',str(DATA/'pairs/dev.jsonl'),
         '--observations',str(DATA/'observations/low_heterogeneous/seed101/dev.jsonl'),
         '--output',str(dev_out),'--method',helper_m]
    if m == 'oracle_soft_dpo': cmd += ['--oracle',str(DATA/'oracle/dev.jsonl')]
    subprocess.run(cmd, check=True)
    hfdir = V5/'datasets'/'low_heterogeneous'/'seed101'/m
    if hfdir.exists(): shutil.rmtree(hfdir)
    def load_jsonl(path):
        return [json.loads(line) for line in Path(path).open() if line.strip()]
    DatasetDict({'train': Dataset.from_list(load_jsonl(out)), 'dev': Dataset.from_list(load_jsonl(dev_out))}).save_to_disk(str(hfdir))
    print(json.dumps({'method':m,'dataset':str(hfdir)},ensure_ascii=False))
