#!/usr/bin/env bash
set -euo pipefail
REPO=/mnt/hezhisheng/distributionally_robust_dpo-2
V5=/mnt/hezhisheng/su/experiment_handoff_v5
cd "$REPO"
PY="$REPO/.venv/bin/python"
export DS_SKIP_CUDA_CHECK=1 VLLM_CONFIGURE_LOGGING=0
export CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-2,3}
export MASTER_PORT=${MASTER_PORT:-29621}
MODEL="$REPO/models/Llama1b"
METHODS=(hard_dpo soft_dpo label_dro_common tro_trust_common oracle_soft_dpo)
for method in "${METHODS[@]}"; do
  ds="$V5/datasets/low_heterogeneous/seed101/$method"
  out="$V5/outputs/low_heterogeneous_seed101_$method"
  mkdir -p "$out"
  if [[ -f "$out/checkpoints/final_hf/model.safetensors" || -f "$out/final_hf/model.safetensors" ]]; then
    echo "[skip] $method already has final checkpoint"
    continue
  fi
  echo "[train] $method"
  "$PY" /usr/local/bin/deepspeed --include "localhost:${CUDA_VISIBLE_DEVICES}" --master_port "$MASTER_PORT" src/train_alignment.py \
    --save_path "$out" --ckpt_path "$out" --save_hf_ckpt --disable_ds_ckpt \
    --save_steps=-1 --eval_steps=-1 --micro_train_batch_size=1 --train_batch_size=16 \
    --gradient_checkpointing --zero_stage=2 --bf16 --no-flash_attn --torch_adam \
    --learning_rate=5e-7 --lr_warmup_ratio=0.1 --max_norm=1.0 --adam_betas 0.9 0.95 --l2=0 \
    --zpg=2 --train_task=tro --tro_method="$method" --max_epochs=2 --beta=0.01 \
    --pretrain "$MODEL" --ref_pretrain "$MODEL" --dataset "$ds" --prompt_key=prompt \
    --chosen_key=chosen --rejected_key=rejected --apply_chat_template --max_len=512 \
    --dataset_num_processors=1 --train_split=train --eval_split=dev --seed=101 \
    2>&1 | tee "$V5/logs/train_${method}.log"
done
