# DPO TRO 逐题信任与统一保守程度实验交付

日期：2026-10-30。版本：2026-10-30-v5-2048-convergence。请从 `EXPERIMENT_PROTOCOL.md` 开始；当前工作区仅保留这一版实验交付。本包是实验规格和 CPU 数学参考，不是已经完成的 LLM 训练工程。

本轮优先交付四项：

1. 训练最大序列长度由旧 pilot 的 512 扩至 **2048 tokens**，五组主实验及所有 N 档位一致。先检查实际分词器、完整文本和资源；不自动降为 1536/1024。
2. **联合搜索 rho×c**：非零 rho={0.005,0.05,0.1}，c={1,3,5}，再包含 soft / DRO 退化端点；各方法独立按开发集逐题 oracle 短缺 S_O 选择。最终测试不参与调参。
3. **必须补充收敛性测试**：仅比较 soft DPO 与 oracle soft DPO：每题同样 N，依次取 **1、5、11、51、101**。N 是模拟投票人数，训练后每个 prompt 仍生成 K=10 个回答；同一冻结 Skywork 评分。
4. 生成主要差距采用 **逐题 mean(max(oracle_prompt_mean − method_prompt_mean, 0))**：超过 oracle 的题记零，低于 oracle 的题计差值，再题间平均。主结果仅为平均 RM 奖励 R↑ 和逐题短缺 S_O↓；偏好概率与交叉熵降为可选诊断。

模型定义：`lambda_trust_i * soft_loss_i + (1 - lambda_trust_i) * worst_loss_i`。lambda 越大越信任经验比例；rho 是所有题共享的 KL 半径。不得默认增加逐题半径、置信区间包络半径或此前的 gamma 校准。

两部分实验：第一部分检验 soft DPO 随投票数增加向 oracle 靠近；第二部分检验异质且有限投票下 TRO 相对 soft DPO、调优的统一半径 DRO 是否减少 oracle 差距。lambda 首轮候选为 N_i/(N_i+c)，c 是全局选参量；它是信任权重，不是精确统计置信概率。

模型分工：计划训练的是 **Llama-3.2-1B-Instruct**；**Skywork-Reward-V2-Llama-3.1-8B** 是冻结的 8B 奖励模型，负责给回答打分、定义模拟 oracle 概率，以及评估训练后生成的回答。DPO 参考模型是冻结的初始策略副本；oracle 策略则是用精确 p* 训练得到的另一个策略模型。完整解释、评分含义与官方来源见 `EXPERIMENT_PROTOCOL.md` 第 4 节。最新 Skywork manifest 声明了 1B 型号；具体 revision、模板与实际加载路径仍须记录。

文件：

- `EXPERIMENT_PROTOCOL.md`：可直接交给合作者的完整流程、公式、选参和验收。
- `experiment_config.json`：机器可读计划；null 字段须在服务器解析，不能视为已运行配置。
- `LENGTH_AUDIT.md`：支持扩大训练长度的数据源统计与复核边界；不等于实际 pilot 截断率。
- `reference_math.py`：统一新 lambda 含义的标量损失、梯度和 KL 端点参考；运行 `python3 reference_math.py`。
- `PILOT_AUDIT.md`：早期 ArmoRM 报告审计，保留为历史证据，不是最新 Skywork 结果。
- `VALIDATION.md` 与 `validation_results.json`：本地实际核验范围。
- `PACKAGE_CONTENTS.json`：包内文件 SHA256。

历史报告的 TRO-common 已有统一 rho 和人数相关混合权重。如果旧 lambda 是鲁棒权重 N0/(N_i+N0)，新 lambda_trust=N_i/(N_i+c)、c=N0 时是完全相同的目标，改名本身不是算法贡献。接手后先检查旧实现，避免只改公式、不改训练分支。

本轮不额外污染 p*，只用二项采样产生带噪经验比例；不更换 RM 或数据集。评测新增逐 prompt 的正部性能短缺 mean(max(oracle_prompt_mean-method_prompt_mean,0))，主表同时报告平均 RM 奖励，原始分数保留；固定回答对概率诊断可选。

执行顺序：2048 长度与实现审计、冻结短缺指标 → 2,000 对少量异质投票五组实验及联合开发选参 → 配置冻结与至少 3 次独立重复 → 必做五档统一 N 收敛性测试 → 后续机制消融和可选扩大。新主场景 N_i={1,3,5}；旧 pilot 的 {1,3,5,7,9} 仍按历史配置报告。当前不要求全量，也不更换数据集或 RM。先报告实际可用资源及运行矩阵；遇到资源限制先调整 microbatch/梯度累积；无法维持 2048 时反馈问题，不能自行缩短输入。该交付不授权新购算力或外部付费服务。

参数明细见协议第 7 节：逐行列出九个 TRO 组合、三种 c 对应的逐题信任权重、两次开发筛选步骤和作业预算。按三次最终重复及 oracle 复用，上限为开发 20 次、最终 30 次训练（不含 smoke/失败/消融）；分阶段执行，不自动启动。

本次网格定稿为 rho={0.005,0.05,0.1} × c={1,3,5}，仍为九组 TRO。旧 rho=0.05、c=10 仅作可选历史复核，须按新清单和设置重训，额外预算单列。DPO beta=0.01 未变。协议第 7 节解释 KL 半径对应的概率范围及小样本边界现象，末尾提供阶段回传表。

收敛性测试单独交付：N=1、5、11、51、101，所有题在同一档内人数相同；每个 N 独立训练 soft DPO，同重复 oracle 可在配置完全一致时复用。至少三次重复，提交 R 随 N 的曲线（含 oracle 参照）及 S_O 随 N 的曲线。N 是偏好投票数，评测生成次数 K 始终为 10。该实验不是可选项目，不能只交异质人数五组实验。
