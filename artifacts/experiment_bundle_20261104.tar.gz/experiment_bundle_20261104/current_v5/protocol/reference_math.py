"""CPU-only mathematical reference for v5: lambda means empirical trust.

No model or dataset downloads. This is not the production trainer.
Run `python3 reference_math.py` to check identities and numerical edge cases.
"""

import json
import math
import random


def sigmoid(z):
    if z >= 0:
        return 1.0 / (1.0 + math.exp(-z))
    exp_z = math.exp(z)
    return exp_z / (1.0 + exp_z)


def softplus(z):
    return max(z, 0.0) + math.log1p(math.exp(-abs(z)))


def soft_loss(z, probability):
    assert 0.0 <= probability <= 1.0
    # This form avoids subtracting two large nearly equal numbers.
    return probability * softplus(-z) + (1.0 - probability) * softplus(z)


def bernoulli_kl(empirical, candidate):
    """KL(Ber(empirical) || Ber(candidate)); natural logarithms."""
    assert 0.0 <= empirical <= 1.0
    assert 0.0 <= candidate <= 1.0
    if empirical == candidate:
        return 0.0
    if candidate == 0.0 or candidate == 1.0:
        return math.inf
    if empirical == 0.0:
        return -math.log1p(-candidate)
    if empirical == 1.0:
        return -math.log(candidate)
    return (
        empirical * (math.log(empirical) - math.log(candidate))
        + (1.0 - empirical)
        * (math.log1p(-empirical) - math.log1p(-candidate))
    )


def kl_interval(empirical, radius, steps=100):
    """Endpoints of KL(Ber(empirical) || Ber(p)) <= radius."""
    assert 0.0 <= empirical <= 1.0
    assert math.isfinite(radius) and radius >= 0.0
    if radius == 0.0:
        return empirical, empirical
    if empirical == 0.0:
        return 0.0, -math.expm1(-radius)
    if empirical == 1.0:
        return math.exp(-radius), 1.0
    outside, inside = 0.0, empirical
    for _ in range(steps):
        mid = (outside + inside) / 2.0
        if bernoulli_kl(empirical, mid) > radius:
            outside = mid
        else:
            inside = mid
    lower = inside
    inside, outside = empirical, 1.0
    for _ in range(steps):
        mid = (inside + outside) / 2.0
        if bernoulli_kl(empirical, mid) > radius:
            outside = mid
        else:
            inside = mid
    return lower, inside


def lambda_trust_from_n(n_votes, c):
    """Candidate trust curve; not a calibrated confidence probability."""
    assert n_votes > 0 and c >= 0.0
    return 0.0 if math.isinf(c) else n_votes / (n_votes + c)


def tro_loss_and_gradient(z, empirical, lower, upper, lam):
    """Returns loss and its derivative w.r.t. margin z, not model weights.

    Lambda is empirical trust. At z=0 chooses the empirical-center subgradient.
    """
    assert 0.0 <= lower <= empirical <= upper <= 1.0
    assert 0.0 <= lam <= 1.0
    worst = lower if z > 0 else upper if z < 0 else empirical
    target = lam * empirical + (1.0 - lam) * worst
    return soft_loss(z, target), sigmoid(z) - target


def _close(left, right, atol=1e-10):
    assert math.isclose(left, right, rel_tol=1e-9, abs_tol=atol), (left, right)


def run_self_checks():
    rng = random.Random(260126)
    identity_error = 0.0
    gradient_error = 0.0
    kl_residual = 0.0
    for _ in range(500):
        empirical = rng.uniform(0.02, 0.98)
        radius = rng.uniform(0.0001, 0.15)
        lower, upper = kl_interval(empirical, radius)
        assert lower <= empirical <= upper
        for endpoint in (lower, upper):
            error = abs(bernoulli_kl(empirical, endpoint) - radius)
            kl_residual = max(kl_residual, error)
            assert error < 1e-8

        lam = rng.random()
        z = rng.choice([-1, 1]) * rng.uniform(0.01, 8.0)
        value, grad = tro_loss_and_gradient(z, empirical, lower, upper, lam)
        mix = lam * soft_loss(z, empirical) + (1 - lam) * max(
            soft_loss(z, lower), soft_loss(z, upper)
        )
        expanded = soft_loss(z, empirical) + (1 - lam) * (
            (empirical - lower) * max(z, 0.0)
            + (upper - empirical) * max(-z, 0.0)
        )
        shrunk_lower = lam * empirical + (1 - lam) * lower
        shrunk_upper = lam * empirical + (1 - lam) * upper
        contracted = max(soft_loss(z, shrunk_lower), soft_loss(z, shrunk_upper))
        for alternate in (mix, expanded, contracted):
            identity_error = max(identity_error, abs(value - alternate))
            _close(value, alternate)

        # Independent dense inner maximization, including endpoints.
        grid_max = max(soft_loss(z, lower + (upper - lower) * j / 100)
                       for j in range(101))
        _close(grid_max, max(soft_loss(z, lower), soft_loss(z, upper)))

        step = 1e-5
        plus = tro_loss_and_gradient(z + step, empirical, lower, upper, lam)[0]
        minus = tro_loss_and_gradient(z - step, empirical, lower, upper, lam)[0]
        numeric_grad = (plus - minus) / (2 * step)
        gradient_error = max(gradient_error, abs(grad - numeric_grad))
        _close(grad, numeric_grad, atol=2e-9)

        swapped_value, swapped_grad = tro_loss_and_gradient(
            -z, 1 - empirical, 1 - upper, 1 - lower, lam
        )
        _close(value, swapped_value)
        _close(grad, -swapped_grad)
        _close(tro_loss_and_gradient(z, empirical, lower, upper, 1)[0],
               soft_loss(z, empirical))
        _close(tro_loss_and_gradient(z, empirical, lower, upper, 0)[0], grid_max)

    for empirical in (0.0, 0.1, 0.5, 0.9, 1.0):
        for radius in (0.0, 1e-6, 0.01, 0.5, 2.0):
            lower, upper = kl_interval(empirical, radius)
            assert 0 <= lower <= empirical <= upper <= 1
            for z in (-1000.0, -2.0, 0.0, 2.0, 1000.0):
                for lam in (0.0, 0.5, 1.0):
                    value, grad = tro_loss_and_gradient(z, empirical, lower, upper, lam)
                    assert math.isfinite(value) and math.isfinite(grad)
                    if z == 0:
                        _close(value, math.log(2))
                        _close(grad, 0.5 - empirical)
                    if radius == 0:
                        _close(value, soft_loss(z, empirical))

    for n_votes in (5, 10, 20, 100):
        for k in range(n_votes + 1):
            empirical = k / n_votes
            for z in (-3.0, 0.0, 3.0):
                explicit = (k * soft_loss(z, 1.0)
                            + (n_votes - k) * soft_loss(z, 0.0)) / n_votes
                _close(explicit, soft_loss(z, empirical))
                explicit_grad = (k * (sigmoid(z) - 1)
                                 + (n_votes - k) * sigmoid(z)) / n_votes
                _close(explicit_grad, sigmoid(z) - empirical)

    # Trust increases with annotation count, and exactly complements old weights.
    for c in (0.0, 1.0, 3.0, 10.0, 30.0, 100.0, math.inf):
        weights = [lambda_trust_from_n(n, c) for n in (1, 3, 5, 10, 20, 100, 1000)]
        assert weights == sorted(weights)
        for n in (1, 5, 20, 100):
            trust = lambda_trust_from_n(n, c)
            old_robust_weight = 1.0 if math.isinf(c) else c / (n + c)
            _close(trust + old_robust_weight, 1.0)
            for z in (-3.0, 0.0, 3.0):
                h = 0.7
                a, b = kl_interval(h, 0.05)
                worst = a if z > 0 else b if z < 0 else h
                old_target = (1-old_robust_weight)*h + old_robust_weight*worst
                val, grad = tro_loss_and_gradient(z, h, a, b, trust)
                _close(val, soft_loss(z, old_target))
                _close(grad, sigmoid(z)-old_target)

    return {
        "status": "passed",
        "random_identity_cases": 500,
        "max_loss_identity_error": identity_error,
        "max_finite_difference_margin_gradient_error": gradient_error,
        "max_regular_case_kl_endpoint_residual": kl_residual,
        "trust_semantics": "lambda=1 soft; lambda=0 DRO",
        "old_robust_weight_complement_checks": "passed",
        "scope": "scalar mathematics only; no PyTorch autograd, GPU, RM or LLM training tested"
    }


if __name__ == "__main__":
    print(json.dumps(run_self_checks(), ensure_ascii=False, indent=2))
