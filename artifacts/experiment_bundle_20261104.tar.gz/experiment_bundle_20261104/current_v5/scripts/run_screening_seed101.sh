#!/usr/bin/env bash
set -euo pipefail

REPO=/mnt/hezhisheng/distributionally_robust_dpo-2
V=/mnt/hezhisheng/su/1030-lastest/experiment_handoff_v5
PY="$REPO/.venv/bin/python"
MODEL="$REPO/models/Llama1b"
GPUS="${GPUS:-3,5}"
PORT="${MASTER_PORT:-29641}"
WORLD_SIZE="$(awk -F, '{print NF}' <<< "$GPUS")"
export DS_SKIP_CUDA_CHECK=1 VLLM_CONFIGURE_LOGGING=0
mkdir -p "$V/outputs" "$V/logs"

train_one() {
  local method="$1" tag="$2" rho="$3" c="$4"
  local ds="$V/datasets/$tag/$method"
  local out="$V/outputs/screen101_${method}_${tag#screen101_}"
  if [[ -f "$out/final_hf/model.safetensors" ]]; then
    echo "[skip] $method $tag"
    return
  fi
  mkdir -p "$out"
  echo "[train] method=$method tag=$tag rho=$rho c=$c"
  CUDA_VISIBLE_DEVICES="$GPUS" SLURM_GPUS_ON_NODE="$WORLD_SIZE" MASTER_PORT="$PORT" \
    "$PY" /usr/local/bin/deepspeed --include "localhost:$GPUS" --master_port "$PORT" "$REPO/src/train_alignment.py" \
      --save_path "$out" --ckpt_path "$out" --save_hf_ckpt --disable_ds_ckpt \
      --save_steps=-1 --eval_steps=-1 --micro_train_batch_size=1 --train_batch_size=128 \
      --gradient_checkpointing --zero_stage=2 --bf16 --no-flash_attn --torch_adam \
      --learning_rate=5e-7 --lr_warmup_ratio=0.1 --max_norm=1.0 --adam_betas 0.9 0.95 --l2=0 --zpg=2 \
      --train_task=tro --tro_method="$method" --max_epochs=2 --beta=0.01 \
      --pretrain "$MODEL" --ref_pretrain "$MODEL" --dataset "$ds" --prompt_key=prompt \
      --chosen_key=chosen --rejected_key=rejected --apply_chat_template --max_len=2048 \
      --dataset_num_processors=1 --train_split=train --eval_split=dev --seed=1101 \
      2>&1 | tee "$V/logs/train_screen101_${method}_${tag#screen101_}.log"
}

# One hard, one soft, one oracle, three common-radius DRO runs, and nine TRO
# interior grid points. Shared endpoint objectives are trained once.
train_one hard_dpo screen101_r005c3 0.005 3
train_one soft_dpo screen101_r005c3 0.005 3
train_one oracle_soft_dpo screen101_r005c3 0.005 3
for spec in r0005c1:0.005:1 r005c1:0.05:1 r01c1:0.1:1; do
  IFS=: read -r tag rho c <<< "$spec"
  train_one label_dro_common "screen101_$tag" "$rho" "$c"
done
for spec in r0005c1:0.005:1 r0005c3:0.005:3 r0005c5:0.005:5 r005c1:0.05:1 r005c3:0.05:3 r005c5:0.05:5 r01c1:0.1:1 r01c3:0.1:3 r01c5:0.1:5; do
  IFS=: read -r tag rho c <<< "$spec"
  train_one tro_trust_common "screen101_$tag" "$rho" "$c"
done

echo "screening seed101 training complete"
