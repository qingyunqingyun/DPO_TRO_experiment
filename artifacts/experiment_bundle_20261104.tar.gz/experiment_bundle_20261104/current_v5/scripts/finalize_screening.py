#!/usr/bin/env python3
import json, time
from pathlib import Path
import subprocess

ROOT = Path('/mnt/hezhisheng/su/1030-lastest/experiment_handoff_v5')
ORACLE = ROOT/'eval/screen101_dev_oracle_soft_dpo/scored.jsonl'
candidates = {
 'hard_dpo':'hard_dpo','soft_dpo':'soft_dpo','label_dro_r0005':'label_dro_r0005',
 'label_dro_r005':'label_dro_r005','label_dro_r01':'label_dro_r01',
 **{f'tro_r{r}c{c}':f'tro_r{r}c{c}' for r in ('0005','005','01') for c in (1,3,5)},
}
PY='/mnt/hezhisheng/distributionally_robust_dpo-2/.venv/bin/python'
while True:
    paths={}; complete=True
    for name, short in candidates.items():
        p=ROOT/'eval'/f'screen101_dev_{short}'/'scored.jsonl'
        if not p.exists() or sum(1 for _ in p.open()) != 5000: complete=False
        else: paths[name]=p
    if complete and ORACLE.exists() and sum(1 for _ in ORACLE.open()) == 5000:
        args=[PY,str(ROOT/'metrics_shortfall.py'),'--oracle',str(ORACLE),'--output',str(ROOT/'eval/screening_seed101_metrics.json'),'--bootstrap','2000']
        for name,p in paths.items(): args.append(f'{name}={p}')
        subprocess.run(args, check=True)
        manifest=ROOT/'resolved_runtime_manifest.json'; d=json.loads(manifest.read_text()); d['status']='screening_dev_evaluation_complete'; d['screening_metrics']=str(ROOT/'eval/screening_seed101_metrics.json'); manifest.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
        break
    time.sleep(60)
