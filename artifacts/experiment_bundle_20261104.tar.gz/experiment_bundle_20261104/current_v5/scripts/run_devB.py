#!/usr/bin/env python3
import os, subprocess, json
from pathlib import Path
ROOT=Path('/mnt/hezhisheng/su/1030-lastest/experiment_handoff_v5')
REPO=Path('/mnt/hezhisheng/distributionally_robust_dpo-2'); PY=str(REPO/'.venv/bin/python'); MODEL=str(REPO/'models/Llama1b')
train_pairs=ROOT/'data/pairs/train.jsonl'; dev_pairs=ROOT/'data/pairs/dev.jsonl'; train_oracle=ROOT/'data/oracle/train.jsonl'; dev_oracle=ROOT/'data/oracle/dev.jsonl'
jobs=[
 ('label_dro_common','r01c1',0.1,1),
 ('label_dro_common','r0005c1',0.005,1),
 ('tro_trust_common','r0005c1',0.005,1),
 ('tro_trust_common','r01c5',0.1,5),
 ('oracle_soft_dpo','oracle',0.005,3),
]
def sh(cmd, env=None, log=None):
    with open(log,'a') as f: subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
def prep(method, tag, rho, c):
    full='devB_'+tag
    cmd=[PY,str(ROOT/'prepare_v5_records.py'),'--root',str(ROOT),'--train-pairs',str(train_pairs),'--dev-pairs',str(dev_pairs),'--train-oracle',str(train_oracle),'--dev-oracle',str(dev_oracle),'--vote-seed','102','--rho',str(rho),'--c',str(c),'--tag',full]
    subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL)
    return full
def train(method, tag, rho, c):
    full=prep(method,tag,rho,c); out=ROOT/'outputs'/f'devB_{method}_{tag}'
    if (out/'final_hf/model.safetensors').exists(): return
    ds=ROOT/'datasets'/full/method
    out.mkdir(parents=True,exist_ok=True); log=ROOT/'logs'/f'train_devB_{method}_{tag}.log'
    cmd=[PY, '-m','deepspeed.launcher.runner','--include','localhost:4,5','--master_port','29652',str(REPO/'src/train_alignment.py'), '--save_path',str(out),'--ckpt_path',str(out),'--save_hf_ckpt','--disable_ds_ckpt','--save_steps=-1','--eval_steps=-1','--micro_train_batch_size=1','--train_batch_size=128','--gradient_checkpointing','--zero_stage=2','--bf16','--no-flash_attn','--torch_adam','--learning_rate=5e-7','--lr_warmup_ratio=0.1','--max_norm=1.0','--adam_betas','0.9','0.95','--l2=0','--zpg=2','--train_task','tro','--tro_method',method,'--max_epochs','2','--beta','0.01','--pretrain',MODEL,'--ref_pretrain',MODEL,'--dataset',str(ds),'--prompt_key','prompt','--chosen_key','chosen','--rejected_key','rejected','--apply_chat_template','--max_len','2048','--dataset_num_processors','1','--train_split','train','--eval_split','dev','--seed','1102']
    env={**os.environ,'CUDA_VISIBLE_DEVICES':'4,5','SLURM_GPUS_ON_NODE':'2','MASTER_PORT':'29652','DS_SKIP_CUDA_CHECK':'1'}
    sh(cmd,env,log)
if __name__=='__main__':
    for j in jobs: train(*j)
