#!/usr/bin/env python3
"""Build the new v5 fixed manifests and enforce the 2048-token full-text filter."""
from __future__ import annotations

import argparse, json, sys
from pathlib import Path

REPO = Path('/mnt/hezhisheng/distributionally_robust_dpo-2')
sys.path.insert(0, str(REPO / 'src'))
from tro_data import build_fixed_pairs  # noqa: E402
from transformers import AutoTokenizer  # noqa: E402


def read_jsonl(path: Path):
    return [json.loads(x) for x in path.open() if x.strip()]


def token_len(tok, messages):
    ids = tok.apply_chat_template(messages, tokenize=True, add_generation_prompt=False)
    return len(ids)


def filter_pairs(src: Path, dst: Path, tok, max_len: int):
    kept, rejected = [], []
    for row in read_jsonl(src):
        try:
            l1 = token_len(tok, row['prompt'] + row['response_1'])
            l2 = token_len(tok, row['prompt'] + row['response_2'])
        except Exception as exc:
            row['reject_reason'] = f'tokenization:{type(exc).__name__}'
            rejected.append(row)
            continue
        row['token_length_1'] = int(l1)
        row['token_length_2'] = int(l2)
        row['max_token_length'] = int(max(l1, l2))
        if max(l1, l2) <= max_len:
            kept.append(row)
        else:
            row['reject_reason'] = 'full_text_over_2048'
            rejected.append(row)
    dst.parent.mkdir(parents=True, exist_ok=True)
    with dst.open('w') as f:
        for row in kept:
            f.write(json.dumps(row, ensure_ascii=False) + '\n')
    return kept, rejected


def write(path: Path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w') as f:
        for x in rows:
            f.write(json.dumps(x, ensure_ascii=False) + '\n')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--train-source', default='/mnt/hezhisheng/su/experiment_handoff_v3/raw/train_prefs.parquet')
    ap.add_argument('--test-source', default='/mnt/hezhisheng/su/experiment_handoff_v3/raw/test_prefs.parquet')
    ap.add_argument('--policy-tokenizer', default='/mnt/hezhisheng/distributionally_robust_dpo-2/models/Llama1b')
    ap.add_argument('--output', default='/mnt/hezhisheng/su/1030-lastest/experiment_handoff_v5/data')
    ap.add_argument('--max-len', type=int, default=2048)
    ap.add_argument('--dev-target', type=int, default=500)
    ap.add_argument('--train-target', type=int, default=2000)
    ap.add_argument('--test-target', type=int, default=500)
    args = ap.parse_args()
    out = Path(args.output); pairs = out / 'pairs'; raw = out / 'raw'
    tok = AutoTokenizer.from_pretrained(args.policy_tokenizer, use_fast=True)
    # Build deterministic one-pair-per-prompt manifests before length filtering.
    build_fixed_pairs(args.train_source, raw / 'train_all.jsonl', split='train_all', response_order_seed=1730)
    build_fixed_pairs(args.test_source, raw / 'test_all.jsonl', split='test_all', response_order_seed=1730)
    train_all, train_rej = filter_pairs(raw / 'train_all.jsonl', raw / 'train_filtered.jsonl', tok, args.max_len)
    test_all, test_rej = filter_pairs(raw / 'test_all.jsonl', raw / 'test_filtered.jsonl', tok, args.max_len)
    # The source split is already prompt-disjoint. Keep deterministic pair order,
    # reserve the first dev block, then take the pilot train block.
    if len(train_all) < args.dev_target + args.train_target:
        raise RuntimeError(f'only {len(train_all)} eligible train pairs; need {args.dev_target + args.train_target}')
    dev = train_all[:args.dev_target]
    train = train_all[args.dev_target:args.dev_target + args.train_target]
    test = test_all[:args.test_target]
    write(pairs / 'dev.jsonl', dev); write(pairs / 'train.jsonl', train); write(pairs / 'test_diagnostic.jsonl', test)
    summary = {
        'tokenizer': args.policy_tokenizer,
        'max_len': args.max_len,
        'raw_unique_train': len(read_jsonl(raw / 'train_all.jsonl')),
        'raw_unique_test': len(read_jsonl(raw / 'test_all.jsonl')),
        'eligible_train': len(train_all), 'eligible_test': len(test_all),
        'filtered_train': len(train_rej), 'filtered_test': len(test_rej),
        'train': len(train), 'dev': len(dev), 'test_diagnostic': len(test),
        'train_max_token_length': max(x['max_token_length'] for x in train),
        'dev_max_token_length': max(x['max_token_length'] for x in dev),
        'test_max_token_length': max(x['max_token_length'] for x in test),
    }
    (out / 'length_filter_manifest.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
