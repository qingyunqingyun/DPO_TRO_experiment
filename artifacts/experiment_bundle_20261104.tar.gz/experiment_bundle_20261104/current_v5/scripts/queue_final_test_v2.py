#!/usr/bin/env python3
import os, subprocess, concurrent.futures, json
from pathlib import Path
ROOT=Path('/mnt/hezhisheng/su/1030-lastest/experiment_handoff_v5'); PY='/mnt/hezhisheng/distributionally_robust_dpo-2/.venv/bin/python'; RM='/mnt/hezhisheng/su/experiment_handoff_v5/models/Skywork-Reward-V2-Llama-3.1-8B'
jobs=[(r,m,4) for r in (1,2,3) for m in ('hard_dpo','soft_dpo','label_dro_common','tro_trust_common','oracle_soft_dpo')]
def run(x):
 r,m,g=x; name=f'final{r}_{m}'; d=ROOT/'eval'/'final_test'/name; d.mkdir(parents=True,exist_ok=True); gen=d/'generations.jsonl'; score=d/'scored.jsonl'; out=ROOT/'outputs'/name/'final_hf'; log=ROOT/'logs'/f'test_{name}.log'; env={**os.environ,'CUDA_VISIBLE_DEVICES':str(g)}
 with log.open('a') as f:
  if not gen.exists() or sum(1 for _ in gen.open())!=5000:
   subprocess.run([PY,str(ROOT/'generate_eval.py'),'--model',str(out),'--pairs',str(ROOT/'data/pairs/test_diagnostic.jsonl'),'--output',str(gen),'--k','10','--seed',str(2400+r),'--max-new-tokens','1024','--max-model-len','4096','--gpu-memory-utilization','0.5'],env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
  if not score.exists() or sum(1 for _ in score.open())!=5000:
   subprocess.run([PY,'/mnt/hezhisheng/su/experiment_handoff_v5/score_skywork.py','--model',RM,'--input',str(gen),'--output',str(score),'--mode','responses','--batch-size','2','--max-length','4096','--device','cuda:0'],env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
if __name__=='__main__':
 for j in jobs: run(j)
 m=ROOT/'resolved_runtime_manifest.json'; d=json.loads(m.read_text()); d['status']='final_test_running'; d['final_test_queue']='queue_final_test_v2.py'; m.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
