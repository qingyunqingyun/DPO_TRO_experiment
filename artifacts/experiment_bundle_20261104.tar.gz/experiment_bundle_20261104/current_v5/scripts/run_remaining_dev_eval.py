#!/usr/bin/env python3
import os, subprocess
from pathlib import Path

ROOT = Path('/mnt/hezhisheng/su/1030-lastest/experiment_handoff_v5')
POLICY = ROOT / 'data/pairs/dev.jsonl'
RM = Path('/mnt/hezhisheng/su/experiment_handoff_v5/models/Skywork-Reward-V2-Llama-3.1-8B')
PY = '/mnt/hezhisheng/distributionally_robust_dpo-2/.venv/bin/python'
GEN = ROOT / 'generate_eval.py'; SCORE = Path('/mnt/hezhisheng/su/experiment_handoff_v5/score_skywork.py')
jobs = [
 ('tro_r0005c3','screen101_tro_trust_common_r0005c3',3),
 ('tro_r0005c5','screen101_tro_trust_common_r0005c5',4),
 ('tro_r005c1','screen101_tro_trust_common_r005c1',3),
 ('tro_r005c3','screen101_tro_trust_common_r005c3',4),
 ('tro_r005c5','screen101_tro_trust_common_r005c5',3),
 ('tro_r01c1','screen101_tro_trust_common_r01c1',4),
 ('tro_r01c3','screen101_tro_trust_common_r01c3',3),
 ('tro_r01c5','screen101_tro_trust_common_r01c5',4),
]

def run(job):
    name, outname, gpu = job
    d = ROOT / 'eval' / ('screen101_dev_' + name); d.mkdir(parents=True, exist_ok=True)
    gen = d/'generations.jsonl'; scored = d/'scored.jsonl'
    log = ROOT/'logs'/('eval_'+name+'.log'); log.parent.mkdir(exist_ok=True)
    with log.open('a') as f:
        if gen.exists() and sum(1 for _ in gen.open()) == 5000:
            f.write('generation already complete\n')
        else:
            cmd=[PY,str(GEN),'--model',str(ROOT/'outputs'/outname/'final_hf'),'--pairs',str(POLICY),'--output',str(gen),'--k','10','--seed','2101','--max-new-tokens','1024','--max-model-len','4096']
            env={**os.environ,'CUDA_VISIBLE_DEVICES':str(gpu)}
            subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
        if scored.exists() and sum(1 for _ in scored.open()) == 5000:
            f.write('scoring already complete\n')
        else:
            cmd=[PY,str(SCORE),'--model',str(RM),'--input',str(gen),'--output',str(scored),'--mode','responses','--batch-size','2','--max-length','4096','--device','cuda:0']
            env={**os.environ,'CUDA_VISIBLE_DEVICES':str(gpu)}
            subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)

if __name__ == '__main__':
    # One sequential worker per GPU; each worker runs four candidates.
    import concurrent.futures
    by_gpu = {3: [j for j in jobs if j[2] == 3], 4: [j for j in jobs if j[2] == 4]}
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
        futs = [ex.submit(lambda js: [run(j) for j in js], js) for js in by_gpu.values()]
        for f in futs: f.result()
