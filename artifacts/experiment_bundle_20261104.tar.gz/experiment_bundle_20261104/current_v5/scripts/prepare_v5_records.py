#!/usr/bin/env python3
"""Create v5 observation/method records and HF datasets for one config."""
from __future__ import annotations
import argparse, json, shutil, sys
from pathlib import Path

from datasets import Dataset, DatasetDict

REPO = Path('/mnt/hezhisheng/distributionally_robust_dpo-2')
sys.path.insert(0, str(REPO / 'src'))
from tro_data import read_jsonl, simulate_observations, write_method_records  # noqa: E402


def load(path):
    return [json.loads(x) for x in Path(path).open() if x.strip()]


def write_jsonl(path, rows):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w') as f:
        for x in rows: f.write(json.dumps(x, ensure_ascii=False) + '\n')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', required=True)
    ap.add_argument('--train-pairs', required=True)
    ap.add_argument('--dev-pairs', required=True)
    ap.add_argument('--train-oracle', required=True)
    ap.add_argument('--dev-oracle', required=True)
    ap.add_argument('--vote-seed', type=int, required=True)
    ap.add_argument('--rho', type=float, required=True)
    ap.add_argument('--c', type=float, required=True)
    ap.add_argument('--allocation-seed', type=int, default=1731)
    ap.add_argument('--tag', required=True)
    args = ap.parse_args()
    root = Path(args.root); data = root / 'data'; dsroot = root / 'datasets' / args.tag
    methods = ['hard_dpo', 'soft_dpo', 'label_dro_common', 'tro_trust_common', 'oracle_soft_dpo']
    for split, pairpath, oraclepath in [('train', args.train_pairs, args.train_oracle), ('dev', args.dev_pairs, args.dev_oracle)]:
        obs = data / 'observations' / args.tag / f'{split}.jsonl'
        simulate_observations(pairpath, oraclepath, obs, vote_counts=[1,3,5], allocation_seed=args.allocation_seed,
                              vote_seed=args.vote_seed, radius_mode='common', common_radius=args.rho, n0=args.c)
    for method in methods:
        helper = 'tro_common' if method == 'tro_trust_common' else method
        records = {}
        for split, pairpath, oraclepath in [('train', args.train_pairs, args.train_oracle), ('dev', args.dev_pairs, args.dev_oracle)]:
            obs = data / 'observations' / args.tag / f'{split}.jsonl'
            out = data / 'methods' / args.tag / f'{method}_{split}.jsonl'
            write_method_records(pairpath, obs, out, method=helper, oracle_path=oraclepath if method == 'oracle_soft_dpo' else None)
            records[split] = load(out)
        target = dsroot / method
        if target.exists(): shutil.rmtree(target)
        DatasetDict({'train': Dataset.from_list(records['train']), 'dev': Dataset.from_list(records['dev'])}).save_to_disk(str(target))
    meta = {'tag': args.tag, 'vote_seed': args.vote_seed, 'rho': args.rho, 'c': args.c, 'methods': methods,
            'train': len(load(args.train_pairs)), 'dev': len(load(args.dev_pairs))}
    (root / 'data' / 'methods' / args.tag / 'config.json').write_text(json.dumps(meta, indent=2) + '\n')
    print(json.dumps(meta, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
