#!/usr/bin/env python3
import os, subprocess, concurrent.futures
from pathlib import Path

ROOT=Path('/mnt/hezhisheng/su/1030-lastest/experiment_handoff_v5')
PY='/mnt/hezhisheng/distributionally_robust_dpo-2/.venv/bin/python'
RM=Path('/mnt/hezhisheng/su/experiment_handoff_v5/models/Skywork-Reward-V2-Llama-3.1-8B')
pairs=ROOT/'data/pairs/dev.jsonl'
jobs=[('label_dro_r01','devB_label_dro_common_r01c1'),('label_dro_r0005','devB_label_dro_common_r0005c1'),('tro_r0005c1','devB_tro_trust_common_r0005c1'),('tro_r01c5','devB_tro_trust_common_r01c5'),('oracle','devB_oracle_soft_dpo_oracle')]

def run(j):
    name,outname=j; gpu=3
    d=ROOT/'eval'/('devB_'+name); d.mkdir(parents=True,exist_ok=True)
    gen=d/'generations.jsonl'; score=d/'scored.jsonl'; log=ROOT/'logs'/('eval_devB_'+name+'.log')
    env={**os.environ,'CUDA_VISIBLE_DEVICES':str(gpu)}
    with log.open('a') as f:
        if not gen.exists() or sum(1 for _ in gen.open())!=5000:
            subprocess.run([PY,str(ROOT/'generate_eval.py'),'--model',str(ROOT/'outputs'/outname/'final_hf'),'--pairs',str(pairs),'--output',str(gen),'--k','10','--seed','2102','--max-new-tokens','1024','--max-model-len','4096','--gpu-memory-utilization','0.5'],env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
        if not score.exists() or sum(1 for _ in score.open())!=5000:
            subprocess.run([PY,'/mnt/hezhisheng/su/experiment_handoff_v5/score_skywork.py','--model',str(RM),'--input',str(gen),'--output',str(score),'--mode','responses','--batch-size','2','--max-length','4096','--device','cuda:0'],env=env,stdout=f,stderr=subprocess.STDOUT,check=True)

if __name__=='__main__':
    for j in jobs: run(j)
