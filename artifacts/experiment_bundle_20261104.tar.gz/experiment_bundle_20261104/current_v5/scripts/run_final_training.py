#!/usr/bin/env python3
import os, subprocess, sys
from pathlib import Path

ROOT=Path('/mnt/hezhisheng/su/1030-lastest/experiment_handoff_v5')
REPO=Path('/mnt/hezhisheng/distributionally_robust_dpo-2'); PY=str(REPO/'.venv/bin/python'); MODEL=str(REPO/'models/Llama1b')
methods=[('hard_dpo',0.1,1),('soft_dpo',0.1,1),('label_dro_common',0.1,1),('tro_trust_common',0.005,1),('oracle_soft_dpo',0.1,1)]
def prep(tag, vote, rho, c):
    cmd=[PY,str(ROOT/'prepare_v5_records.py'),'--root',str(ROOT),'--train-pairs',str(ROOT/'data/pairs/train.jsonl'),'--dev-pairs',str(ROOT/'data/pairs/dev.jsonl'),'--train-oracle',str(ROOT/'data/oracle/train.jsonl'),'--dev-oracle',str(ROOT/'data/oracle/dev.jsonl'),'--vote-seed',str(vote),'--rho',str(rho),'--c',str(c),'--tag',tag]
    subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL)
def train(rep, vote, trainseed):
    for method,rho,c in methods:
        tag=f'final{rep}_v{vote}_r{str(rho).replace(".","") }c{c}'
        prep(tag,vote,rho,c); out=ROOT/'outputs'/f'final{rep}_{method}'
        if (out/'final_hf/model.safetensors').exists(): continue
        ds=ROOT/'datasets'/tag/method; out.mkdir(parents=True,exist_ok=True)
        log=ROOT/'logs'/f'train_final{rep}_{method}.log'
        cmd=[PY,'-m','deepspeed.launcher.runner','--include','localhost:4,5','--master_port',str(29700+rep),str(REPO/'src/train_alignment.py'),'--save_path',str(out),'--ckpt_path',str(out),'--save_hf_ckpt','--disable_ds_ckpt','--save_steps=-1','--eval_steps=-1','--micro_train_batch_size=1','--train_batch_size=128','--gradient_checkpointing','--zero_stage=2','--bf16','--no-flash_attn','--torch_adam','--learning_rate=5e-7','--lr_warmup_ratio=0.1','--max_norm=1.0','--adam_betas','0.9','0.95','--l2=0','--zpg=2','--train_task','tro','--tro_method',method,'--max_epochs','2','--beta','0.01','--pretrain',MODEL,'--ref_pretrain',MODEL,'--dataset',str(ds),'--prompt_key','prompt','--chosen_key','chosen','--rejected_key','rejected','--apply_chat_template','--max_len','2048','--dataset_num_processors','1','--train_split','train','--eval_split','dev','--seed',str(trainseed)]
        env={**os.environ,'CUDA_VISIBLE_DEVICES':'4,5','DS_SKIP_CUDA_CHECK':'1','MASTER_PORT':str(29700+rep)}
        with log.open('a') as f: subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
if __name__=='__main__':
    rep=int(sys.argv[1]) if len(sys.argv)>1 else 1; vote=int(sys.argv[2]) if len(sys.argv)>2 else 201; trainseed=int(sys.argv[3]) if len(sys.argv)>3 else 301
    train(rep,vote,trainseed)
