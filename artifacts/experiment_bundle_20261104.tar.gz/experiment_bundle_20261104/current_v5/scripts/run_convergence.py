#!/usr/bin/env python3
import json, os, shutil, subprocess, sys
from pathlib import Path
from datasets import Dataset, DatasetDict
ROOT=Path('/mnt/hezhisheng/su/1030-lastest/experiment_handoff_v5'); REPO=Path('/mnt/hezhisheng/distributionally_robust_dpo-2'); PY=str(REPO/'.venv/bin/python'); MODEL=str(REPO/'models/Llama1b')
sys.path.insert(0,str(REPO/'src')); from tro_data import simulate_observations, write_method_records
Ns=[1,5,11,51,101]; reps=[(1,201,301),(2,202,302),(3,203,303)]
def load(p): return [json.loads(x) for x in Path(p).open() if x.strip()]
def prep(rep,vote,n):
 tag=f'conv_r{rep}_n{n}';
 for split in ('train','dev'):
  simulate_observations(ROOT/f'data/pairs/{split}.jsonl',ROOT/f'data/oracle/{split}.jsonl',ROOT/f'data/observations/{tag}/{split}.jsonl',vote_counts=[n],allocation_seed=1731,vote_seed=vote,radius_mode='common',common_radius=0.005,n0=3)
 for method in ('soft_dpo','oracle_soft_dpo'):
  rec={}
  for split in ('train','dev'):
   out=ROOT/f'data/methods/{tag}/{method}_{split}.jsonl'; write_method_records(ROOT/f'data/pairs/{split}.jsonl',ROOT/f'data/observations/{tag}/{split}.jsonl',out,method=method,oracle_path=ROOT/f'data/oracle/{split}.jsonl' if method=='oracle_soft_dpo' else None); rec[split]=load(out)
  target=ROOT/f'datasets/{tag}/{method}';
  if target.exists(): shutil.rmtree(target)
  DatasetDict({'train':Dataset.from_list(rec['train']),'dev':Dataset.from_list(rec['dev'])}).save_to_disk(str(target))
 return tag
def train_one(rep,vote,trainseed,method,tag,out):
 if (out/'final_hf/model.safetensors').exists(): return
 log=ROOT/'logs'/f'train_{out.name}.log'; cmd=[PY,'-m','deepspeed.launcher.runner','--include','localhost:4,5','--master_port',str(29800+rep),str(REPO/'src/train_alignment.py'),'--save_path',str(out),'--ckpt_path',str(out),'--save_hf_ckpt','--disable_ds_ckpt','--save_steps=-1','--eval_steps=-1','--micro_train_batch_size=1','--train_batch_size=128','--gradient_checkpointing','--zero_stage=2','--bf16','--no-flash_attn','--torch_adam','--learning_rate=5e-7','--lr_warmup_ratio=0.1','--max_norm=1.0','--adam_betas','0.9','0.95','--l2=0','--zpg=2','--train_task','tro','--tro_method',method,'--max_epochs','2','--beta','0.01','--pretrain',MODEL,'--ref_pretrain',MODEL,'--dataset',str(ROOT/'datasets'/tag/method),'--prompt_key','prompt','--chosen_key','chosen','--rejected_key','rejected','--apply_chat_template','--max_len','2048','--dataset_num_processors','1','--train_split','train','--eval_split','dev','--seed',str(trainseed)]
 env={**os.environ,'CUDA_VISIBLE_DEVICES':'4,5','DS_SKIP_CUDA_CHECK':'1'}; out.mkdir(parents=True,exist_ok=True)
 with log.open('a') as f: subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
if __name__=='__main__':
 for rep,vote,trainseed in reps:
  oracle_tag=prep(rep,vote,1); train_one(rep,vote,trainseed,'oracle_soft_dpo',oracle_tag,ROOT/f'outputs/conv_r{rep}_oracle')
  for n in Ns:
   tag=prep(rep,vote,n); train_one(rep,vote,trainseed,'soft_dpo',tag,ROOT/f'outputs/conv_r{rep}_n{n}_soft')
