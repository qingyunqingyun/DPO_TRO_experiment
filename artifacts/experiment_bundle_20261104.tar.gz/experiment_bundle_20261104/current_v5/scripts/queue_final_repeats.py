#!/usr/bin/env python3
import subprocess, time
PY='/mnt/hezhisheng/distributionally_robust_dpo-2/.venv/bin/python'
SCRIPT='/mnt/hezhisheng/su/1030-lastest/experiment_handoff_v5/run_final_training.py'
for rep,vote,train in [(2,202,302),(3,203,303)]:
    while True:
        probe=subprocess.run("pgrep -f 'run_final_training.py'",shell=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        if probe.returncode != 0: break
        time.sleep(30)
    subprocess.run([PY,SCRIPT,str(rep),str(vote),str(train)],check=True)
